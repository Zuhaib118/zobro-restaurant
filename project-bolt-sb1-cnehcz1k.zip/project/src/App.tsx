import { useState } from 'react';
import { CartProvider } from '@/context/CartContext';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Categories from '@/components/Categories';
import MenuSection from '@/components/MenuSection';
import About from '@/components/About';
import Offers from '@/components/Offers';
import WhyChooseUs from '@/components/WhyChooseUs';
import Testimonials from '@/components/Testimonials';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';

function App() {
  const [activeCategory, setActiveCategory] = useState('all');

  const handleCategorySelect = (id: string) => {
    setActiveCategory(id);
    document.querySelector('#menu')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <CartProvider>
      <div className="min-h-screen bg-cream-50">
        <Navbar />
        <main>
          <Hero />
          <Categories active={activeCategory} onSelect={handleCategorySelect} />
          <MenuSection activeCategory={activeCategory} onSelectCategory={setActiveCategory} />
          <About />
          <Offers />
          <WhyChooseUs />
          <Testimonials />
          <Contact />
        </main>
        <Footer />
        <CartDrawer />
      </div>
    </CartProvider>
  );
}

export default App;
