import type { MenuCategory, MenuItem, DealItem } from '../types';

export const WHATSAPP_NUMBER = '923332768127';
export const WHATSAPP_DISPLAY = '03332768127';
export const CONTACT_EMAIL = 'zuhaibbrohi0786@gmail.com';

export const categories: MenuCategory[] = [
  { id: 'pizza', name: 'Pizza', short: 'Pizza', image: 'https://images.pexels.com/photos/35819050/pexels-photo-35819050.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Pizza' },
  { id: 'burgers', name: 'Burgers', short: 'Burgers', image: 'https://images.pexels.com/photos/4628465/pexels-photo-4628465.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Beef' },
  { id: 'sandwiches', name: 'Sandwiches', short: 'Sandwiches', image: 'https://images.pexels.com/photos/32715053/pexels-photo-32715053.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Sandwich' },
  { id: 'rolls', name: 'Rolls & Wraps', short: 'Rolls', image: 'https://images.pexels.com/photos/5779364/pexels-photo-5779364.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Burrito' },
  { id: 'broast', name: 'Broast & Fried Chicken', short: 'Broast', image: 'https://images.pexels.com/photos/5474676/pexels-photo-5474676.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Drumstick' },
  { id: 'bbq', name: 'BBQ & Tikka', short: 'BBQ', image: 'https://images.pexels.com/photos/7301037/pexels-photo-7301037.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Flame' },
  { id: 'pakistani', name: 'Pakistani & Sindhi', short: 'Pakistani', image: 'https://images.pexels.com/photos/18601877/pexels-photo-18601877.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Soup' },
  { id: 'fries', name: 'Fries & Sides', short: 'Fries', image: 'https://images.pexels.com/photos/20535803/pexels-photo-20535803.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'FrenchFries' },
  { id: 'momos', name: 'Momos & Asian', short: 'Momos', image: 'https://images.pexels.com/photos/18803177/pexels-photo-18803177.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Dumpling' },
  { id: 'streetfood', name: 'Street Food', short: 'Street Food', image: 'https://images.pexels.com/photos/9738980/pexels-photo-9738980.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Cookie' },
  { id: 'pasta', name: 'Pasta & Italian', short: 'Pasta', image: 'https://images.pexels.com/photos/5639532/pexels-photo-5639532.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Soup' },
  { id: 'rice', name: 'Rice & Combos', short: 'Rice', image: 'https://images.pexels.com/photos/40263070/pexels-photo-40263070.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Rice' },
  { id: 'cakes', name: 'Cakes & Bakery', short: 'Cakes', image: 'https://images.pexels.com/photos/806363/pexels-photo-806363.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Cake' },
  { id: 'desserts', name: 'Desserts', short: 'Desserts', image: 'https://images.pexels.com/photos/10480244/pexels-photo-10480244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'IceCream' },
  { id: 'shakes', name: 'Milkshakes', short: 'Shakes', image: 'https://images.pexels.com/photos/36025971/pexels-photo-36025971.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'CupSoda' },
  { id: 'beverages', name: 'Beverages', short: 'Drinks', image: 'https://images.pexels.com/photos/8541309/pexels-photo-8541309.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'CupSoda' },
  { id: 'icecream', name: 'Ice Cream', short: 'Ice Cream', image: 'https://images.pexels.com/photos/38371324/pexels-photo-38371324.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'IceCream' },
  { id: 'breakfast', name: 'Breakfast & Desi', short: 'Breakfast', image: 'https://images.pexels.com/photos/36388454/pexels-photo-36388454.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Egg' },
  { id: 'kids', name: "Kids' Menu", short: 'Kids', image: 'https://images.pexels.com/photos/19247563/pexels-photo-19247563.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', icon: 'Cookie' },
];

const pizzaImg = 'https://images.pexels.com/photos/35819050/pexels-photo-35819050.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pizzaImg2 = 'https://images.pexels.com/photos/12645172/pexels-photo-12645172.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pizzaImg3 = 'https://images.pexels.com/photos/1082342/pexels-photo-1082342.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pizzaImg4 = 'https://images.pexels.com/photos/12645186/pexels-photo-12645186.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pizzaSlice = 'https://images.pexels.com/photos/365459/pexels-photo-365459.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const burgerImg = 'https://images.pexels.com/photos/4628465/pexels-photo-4628465.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const burgerImg2 = 'https://images.pexels.com/photos/37098536/pexels-photo-37098536.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const burgerImg3 = 'https://images.pexels.com/photos/10701945/pexels-photo-10701945.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const burgerImg4 = 'https://images.pexels.com/photos/3915908/pexels-photo-3915908.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const burgerGrill = 'https://images.pexels.com/photos/37245456/pexels-photo-37245456.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const sandwichImg = 'https://images.pexels.com/photos/32715053/pexels-photo-32715053.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const sandwichImg2 = 'https://images.pexels.com/photos/29614913/pexels-photo-29614913.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const sandwichImg3 = 'https://images.pexels.com/photos/19034914/pexels-photo-19034914.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const sandwichImg4 = 'https://images.pexels.com/photos/29954941/pexels-photo-29954941.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const sandwichImg5 = 'https://images.pexels.com/photos/25946547/pexels-photo-25946547.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const wrapImg = 'https://images.pexels.com/photos/5779364/pexels-photo-5779364.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const wrapImg2 = 'https://images.pexels.com/photos/5175629/pexels-photo-5175629.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const wrapImg3 = 'https://images.pexels.com/photos/16022887/pexels-photo-16022887.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const wrapImg4 = 'https://images.pexels.com/photos/36879216/pexels-photo-36879216.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const wrapImg5 = 'https://images.pexels.com/photos/5779372/pexels-photo-5779372.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const friedImg = 'https://images.pexels.com/photos/5474676/pexels-photo-5474676.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friedImg2 = 'https://images.pexels.com/photos/32177596/pexels-photo-32177596.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friedImg3 = 'https://images.pexels.com/photos/1600714/pexels-photo-1600714.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friedImg4 = 'https://images.pexels.com/photos/15910249/pexels-photo-15910249.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friedImg5 = 'https://images.pexels.com/photos/36879224/pexels-photo-36879224.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const bbqImg = 'https://images.pexels.com/photos/7301037/pexels-photo-7301037.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bbqImg2 = 'https://images.pexels.com/photos/5840331/pexels-photo-5840331.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bbqImg3 = 'https://images.pexels.com/photos/38843562/pexels-photo-38843562.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bbqImg4 = 'https://images.pexels.com/photos/36879455/pexels-photo-36879455.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const bbqImg5 = 'https://images.pexels.com/photos/39059254/pexels-photo-39059254.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const biryaniImg = 'https://images.pexels.com/photos/18601877/pexels-photo-18601877.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const biryaniImg2 = 'https://images.pexels.com/photos/8250738/pexels-photo-8250738.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const biryaniImg3 = 'https://images.pexels.com/photos/37309267/pexels-photo-37309267.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const biryaniImg4 = 'https://images.pexels.com/photos/40262796/pexels-photo-40262796.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const karahiImg = 'https://images.pexels.com/photos/39378356/pexels-photo-39378356.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const karahiImg2 = 'https://images.pexels.com/photos/6113820/pexels-photo-6113820.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const karahiImg3 = 'https://images.pexels.com/photos/6113813/pexels-photo-6113813.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const karahiImg4 = 'https://images.pexels.com/photos/36202022/pexels-photo-36202022.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const karahiImg5 = 'https://images.pexels.com/photos/8992836/pexels-photo-8992836.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const friesImg = 'https://images.pexels.com/photos/20535803/pexels-photo-20535803.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friesImg2 = 'https://images.pexels.com/photos/15838896/pexels-photo-15838896.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friesImg3 = 'https://images.pexels.com/photos/28525214/pexels-photo-28525214.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friesImg4 = 'https://images.pexels.com/photos/20535802/pexels-photo-20535802.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const friesImg5 = 'https://images.pexels.com/photos/9574954/pexels-photo-9574954.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const momosImg = 'https://images.pexels.com/photos/18803177/pexels-photo-18803177.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const momosImg2 = 'https://images.pexels.com/photos/3926123/pexels-photo-3926123.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const momosImg3 = 'https://images.pexels.com/photos/3911228/pexels-photo-3911228.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const momosImg4 = 'https://images.pexels.com/photos/18803174/pexels-photo-18803174.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const momosImg5 = 'https://images.pexels.com/photos/7363685/pexels-photo-7363685.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const streetImg = 'https://images.pexels.com/photos/9738980/pexels-photo-9738980.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const streetImg2 = 'https://images.pexels.com/photos/40263097/pexels-photo-40263097.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const streetImg3 = 'https://images.pexels.com/photos/17050759/pexels-photo-17050759.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const streetImg4 = 'https://images.pexels.com/photos/40047410/pexels-photo-40047410.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const springRollImg = 'https://images.pexels.com/photos/35407775/pexels-photo-35407775.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const pastaImg = 'https://images.pexels.com/photos/5639532/pexels-photo-5639532.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pastaImg2 = 'https://images.pexels.com/photos/11220208/pexels-photo-11220208.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pastaImg3 = 'https://images.pexels.com/photos/5175578/pexels-photo-5175578.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pastaImg4 = 'https://images.pexels.com/photos/28762003/pexels-photo-28762003.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const pastaImg5 = 'https://images.pexels.com/photos/5411629/pexels-photo-5411629.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const riceImg = 'https://images.pexels.com/photos/40263070/pexels-photo-40263070.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const riceImg2 = 'https://images.pexels.com/photos/3926121/pexels-photo-3926121.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const riceImg3 = 'https://images.pexels.com/photos/28445827/pexels-photo-28445827.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const riceImg4 = 'https://images.pexels.com/photos/21482824/pexels-photo-21482824.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const riceImg5 = 'https://images.pexels.com/photos/104884/pexels-photo-104884.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const cakeImg = 'https://images.pexels.com/photos/806363/pexels-photo-806363.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const cakeImg2 = 'https://images.pexels.com/photos/8104140/pexels-photo-8104140.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const cakeImg3 = 'https://images.pexels.com/photos/28254499/pexels-photo-28254499.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const cakeImg4 = 'https://images.pexels.com/photos/39240989/pexels-photo-39240989.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const cakeImg5 = 'https://images.pexels.com/photos/39240987/pexels-photo-39240987.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const dessertImg = 'https://images.pexels.com/photos/10480244/pexels-photo-10480244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const dessertImg2 = 'https://images.pexels.com/photos/5163948/pexels-photo-5163948.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const dessertImg3 = 'https://images.pexels.com/photos/33312981/pexels-photo-33312981.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const dessertImg4 = 'https://images.pexels.com/photos/33674414/pexels-photo-33674414.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const dessertImg5 = 'https://images.pexels.com/photos/33674412/pexels-photo-33674412.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const cheesecakeImg = 'https://images.pexels.com/photos/4669235/pexels-photo-4669235.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const tiramisuImg = 'https://images.pexels.com/photos/1707920/pexels-photo-1707920.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const tiramisuImg2 = 'https://images.pexels.com/photos/4841839/pexels-photo-4841839.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const tiramisuImg3 = 'https://images.pexels.com/photos/15415231/pexels-photo-15415231.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const tiramisuImg4 = 'https://images.pexels.com/photos/29460805/pexels-photo-29460805.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const gulabImg = 'https://images.pexels.com/photos/11887844/pexels-photo-11887844.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const shakeImg = 'https://images.pexels.com/photos/36025971/pexels-photo-36025971.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const shakeImg2 = 'https://images.pexels.com/photos/39948188/pexels-photo-39948188.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const shakeImg3 = 'https://images.pexels.com/photos/7091582/pexels-photo-7091582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const shakeImg4 = 'https://images.pexels.com/photos/20066464/pexels-photo-20066464.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const shakeImg5 = 'https://images.pexels.com/photos/6463655/pexels-photo-6463655.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const drinkImg = 'https://images.pexels.com/photos/8541309/pexels-photo-8541309.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const drinkImg2 = 'https://images.pexels.com/photos/8250366/pexels-photo-8250366.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const drinkImg3 = 'https://images.pexels.com/photos/32612248/pexels-photo-32612248.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const drinkImg4 = 'https://images.pexels.com/photos/33166521/pexels-photo-33166521.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const drinkImg5 = 'https://images.pexels.com/photos/7703248/pexels-photo-7703248.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const icecreamImg = 'https://images.pexels.com/photos/38371324/pexels-photo-38371324.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const icecreamImg2 = 'https://images.pexels.com/photos/14608735/pexels-photo-14608735.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const icecreamImg3 = 'https://images.pexels.com/photos/1362534/pexels-photo-1362534.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const icecreamImg4 = 'https://images.pexels.com/photos/34452066/pexels-photo-34452066.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const icecreamImg5 = 'https://images.pexels.com/photos/7491892/pexels-photo-7491892.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const breakfastImg = 'https://images.pexels.com/photos/36388454/pexels-photo-36388454.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const breakfastImg2 = 'https://images.pexels.com/photos/35079296/pexels-photo-35079296.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const breakfastImg3 = 'https://images.pexels.com/photos/37555450/pexels-photo-37555450.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const breakfastImg4 = 'https://images.pexels.com/photos/1080314/pexels-photo-1080314.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const breakfastImg5 = 'https://images.pexels.com/photos/38834853/pexels-photo-38834853.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const kidsImg = 'https://images.pexels.com/photos/19247563/pexels-photo-19247563.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const kidsImg2 = 'https://images.pexels.com/photos/19247561/pexels-photo-19247561.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const kidsImg3 = 'https://images.pexels.com/photos/4021931/pexels-photo-4021931.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const kidsImg4 = 'https://images.pexels.com/photos/19247566/pexels-photo-19247566.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const kidsImg5 = 'https://images.pexels.com/photos/19247569/pexels-photo-19247569.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const feastImg = 'https://images.pexels.com/photos/29486068/pexels-photo-29486068.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const feastImg2 = 'https://images.pexels.com/photos/17294719/pexels-photo-17294719.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';
const feastImg3 = 'https://images.pexels.com/photos/27177297/pexels-photo-27177297.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

const size = (s: number, m: number, l: number) => ([
  { label: 'Small', price: s },
  { label: 'Medium', price: m },
  { label: 'Large', price: l },
]);

const id = (c: string, n: number) => `${c}-${n}`;

export const menuItems: MenuItem[] = [
  // PIZZA — 20
  { id: id('pizza', 1), name: 'Classic Chicken Tikka Pizza', description: 'Tandoori-spiced chicken, capsicum, onions, and mozzarella on a hand-tossed crust.', price: 1200, image: pizzaImg, category: 'pizza', tags: ['spicy', 'popular'], sizes: size(1200, 1800, 2400) },
  { id: id('pizza', 2), name: 'Chicken Fajita Pizza', description: 'Fajita-marinated chicken, bell peppers, onions, and melted cheese.', price: 1300, image: pizzaImg2, category: 'pizza', tags: ['spicy'], sizes: size(1300, 1900, 2500) },
  { id: id('pizza', 3), name: 'Creamy Fajita Pizza', description: 'Creamy white sauce base with fajita chicken and veggies.', price: 1400, image: pizzaImg3, category: 'pizza', sizes: size(1400, 2000, 2600) },
  { id: id('pizza', 4), name: 'Chicken Supreme Pizza', description: 'Loaded with chicken sausage, mushrooms, capsicum, and extra cheese.', price: 1500, image: pizzaImg4, category: 'pizza', tags: ['popular'], sizes: size(1500, 2100, 2700) },
  { id: id('pizza', 5), name: 'Chicken Tandoori Pizza', description: 'Smoky tandoori chicken with fresh herbs and cheese.', price: 1350, image: pizzaImg, category: 'pizza', tags: ['spicy'], sizes: size(1350, 1950, 2550) },
  { id: id('pizza', 6), name: 'Chicken Malai Boti Pizza', description: 'Creamy malai boti with mild spices and mozzarella.', price: 1450, image: pizzaImg2, category: 'pizza', sizes: size(1450, 2050, 2650) },
  { id: id('pizza', 7), name: 'BBQ Chicken Pizza', description: 'Smoky BBQ sauce, grilled chicken, onions, and cheese.', price: 1500, image: pizzaImg3, category: 'pizza', sizes: size(1500, 2100, 2700) },
  { id: id('pizza', 8), name: 'Chicken Pepperoni-Style Pizza', description: 'Chicken pepperoni slices with rich tomato base.', price: 1400, image: pizzaImg4, category: 'pizza', tags: ['popular'], sizes: size(1400, 2000, 2600) },
  { id: id('pizza', 9), name: "Cheese Lover's Pizza", description: 'Triple cheese blend with mozzarella, cheddar, and parmesan.', price: 1300, image: pizzaImg, category: 'pizza', sizes: size(1300, 1900, 2500) },
  { id: id('pizza', 10), name: 'Four Cheese Pizza', description: 'Mozzarella, cheddar, feta, and parmesan on a classic base.', price: 1600, image: pizzaImg2, category: 'pizza', tags: ['veg'], sizes: size(1600, 2200, 2800) },
  { id: id('pizza', 11), name: 'Margherita Pizza', description: 'Fresh basil, tomato sauce, and mozzarella — simple and classic.', price: 1100, image: pizzaImg3, category: 'pizza', tags: ['veg'], sizes: size(1100, 1700, 2300) },
  { id: id('pizza', 12), name: 'Vegetable Supreme Pizza', description: 'Garden-fresh vegetables with cheese and herbs.', price: 1250, image: pizzaImg4, category: 'pizza', tags: ['veg'], sizes: size(1250, 1850, 2450) },
  { id: id('pizza', 13), name: 'Mushroom Pizza', description: 'Sauteed mushrooms with garlic and cheese.', price: 1250, image: pizzaImg2, category: 'pizza', tags: ['veg'], sizes: size(1250, 1850, 2450) },
  { id: id('pizza', 14), name: 'Mexican Hot Pizza', description: 'Spicy Mexican-style chicken with jalapenos and hot sauce.', price: 1500, image: pizzaImg, category: 'pizza', tags: ['spicy'], sizes: size(1500, 2100, 2700) },
  { id: id('pizza', 15), name: 'Peri Peri Chicken Pizza', description: 'Peri peri marinated chicken with fresh peppers.', price: 1450, image: pizzaImg3, category: 'pizza', tags: ['spicy'], sizes: size(1450, 2050, 2650) },
  { id: id('pizza', 16), name: 'Smoked Chicken Pizza', description: 'Smoked chicken breast with cheese and herbs.', price: 1550, image: pizzaImg4, category: 'pizza', sizes: size(1550, 2150, 2750) },
  { id: id('pizza', 17), name: 'Creamy Garlic Chicken Pizza', description: 'Creamy garlic base with grilled chicken and cheese.', price: 1450, image: pizzaImg2, category: 'pizza', sizes: size(1450, 2050, 2650) },
  { id: id('pizza', 18), name: 'Crown Crust Pizza', description: 'Cheese-filled crown crust with your favorite toppings.', price: 1700, image: pizzaImg, category: 'pizza', tags: ['chef'], sizes: size(1700, 2300, 2900) },
  { id: id('pizza', 19), name: 'Stuffed Crust Pizza', description: 'Molten cheese stuffed crust with loaded toppings.', price: 1750, image: pizzaImg3, category: 'pizza', tags: ['chef'], sizes: size(1750, 2350, 2950) },
  { id: id('pizza', 20), name: 'ZOBRO Special Pizza', description: 'Our signature — loaded with chicken, cheese, and secret ZOBRO sauce.', price: 1900, image: pizzaImg4, category: 'pizza', tags: ['chef', 'popular'], sizes: size(1900, 2500, 3100) },

  // BURGERS — 20
  { id: id('burgers', 1), name: 'Classic Beef Burger', description: 'Juicy beef patty, lettuce, tomato, and ZOBRO sauce.', price: 550, image: burgerImg, category: 'burgers', extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 2), name: 'Double Beef Burger', description: 'Two beef patties stacked with cheese and sauce.', price: 750, image: burgerImg2, category: 'burgers', tags: ['popular'], extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 3), name: 'Triple Cheese Beef Burger', description: 'Three patties, three slices of cheese — for serious hunger.', price: 950, image: burgerImg3, category: 'burgers', extras: ['Meal Upgrade +250'] },
  { id: id('burgers', 4), name: 'Smash Burger', description: 'Crispy-edged smashed beef patty with pickles and house sauce.', price: 650, image: burgerImg4, category: 'burgers', extras: ['Extra Cheese +100'] },
  { id: id('burgers', 5), name: 'ZOBRO Signature Burger', description: 'Our signature double patty with special ZOBRO sauce and cheese.', price: 890, image: burgerImg, category: 'burgers', tags: ['chef', 'popular'], extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 6), name: 'Crispy Chicken Burger', description: 'Crispy fried chicken fillet with fresh lettuce and mayo.', price: 520, image: burgerGrill, category: 'burgers', extras: ['Extra Cheese +100', 'Spicy +50', 'Meal Upgrade +250'] },
  { id: id('burgers', 7), name: 'Spicy Crispy Chicken Burger', description: 'Hot and crispy chicken fillet with spicy mayo.', price: 560, image: friedImg2, category: 'burgers', tags: ['spicy'], extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 8), name: 'Zinger Burger', description: 'Classic zinger-style crispy chicken with lettuce and mayo.', price: 580, image: burgerImg3, category: 'burgers', tags: ['popular'], extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 9), name: 'Double Zinger Burger', description: 'Two crispy chicken fillets stacked with cheese.', price: 780, image: burgerImg2, category: 'burgers', extras: ['Meal Upgrade +250'] },
  { id: id('burgers', 10), name: 'Chicken Cheese Burger', description: 'Grilled chicken patty with melted cheese and sauce.', price: 600, image: burgerImg4, category: 'burgers', extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 11), name: 'Grilled Chicken Burger', description: 'Flame-grilled chicken breast with fresh veggies.', price: 620, image: burgerGrill, category: 'burgers', extras: ['Extra Cheese +100'] },
  { id: id('burgers', 12), name: 'BBQ Chicken Burger', description: 'Smoky BBQ chicken patty with caramelized onions.', price: 650, image: burgerImg, category: 'burgers', extras: ['Extra Cheese +100'] },
  { id: id('burgers', 13), name: 'Peri Peri Chicken Burger', description: 'Peri peri marinated chicken with spicy sauce.', price: 650, image: friedImg2, category: 'burgers', tags: ['spicy'], extras: ['Extra Cheese +100'] },
  { id: id('burgers', 14), name: 'Mushroom Swiss Burger', description: 'Beef patty with sauteed mushrooms and Swiss cheese.', price: 700, image: burgerImg3, category: 'burgers', extras: ['Meal Upgrade +250'] },
  { id: id('burgers', 15), name: 'Jalapeno Burger', description: 'Spicy jalapenos with cheese and beef patty.', price: 680, image: burgerImg2, category: 'burgers', tags: ['spicy'], extras: ['Extra Cheese +100'] },
  { id: id('burgers', 16), name: 'Mexican Burger', description: 'Mexican-spiced patty with salsa and jalapenos.', price: 700, image: burgerImg4, category: 'burgers', tags: ['spicy'], extras: ['Extra Cheese +100'] },
  { id: id('burgers', 17), name: 'Fish Burger', description: 'Crispy fish fillet with tartar sauce and lettuce.', price: 650, image: burgerGrill, category: 'burgers', extras: ['Extra Cheese +100'] },
  { id: id('burgers', 18), name: 'Chicken Patty Burger', description: 'Classic chicken patty with cheese and fresh veggies.', price: 500, image: burgerImg, category: 'burgers', extras: ['Extra Cheese +100', 'Meal Upgrade +250'] },
  { id: id('burgers', 19), name: 'Tower Burger', description: 'Triple-stacked crispy chicken with hash brown and cheese.', price: 890, image: burgerImg3, category: 'burgers', tags: ['chef'], extras: ['Meal Upgrade +250'] },
  { id: id('burgers', 20), name: 'Mega Loaded Burger', description: 'Double patty, bacon, egg, cheese, and all the toppings.', price: 1100, image: burgerImg2, category: 'burgers', tags: ['chef', 'popular'], extras: ['Meal Upgrade +250'] },

  // SANDWICHES — 12
  { id: id('sandwiches', 1), name: 'Classic Club Sandwich', description: 'Triple-decker with chicken, egg, and fresh veggies. Served with fries.', price: 480, image: sandwichImg, category: 'sandwiches', tags: ['popular'], serves: '2-3' },
  { id: id('sandwiches', 2), name: 'Chicken Mayo Sandwich', description: 'Creamy chicken mayo with fresh bread.', price: 380, image: sandwichImg2, category: 'sandwiches' },
  { id: id('sandwiches', 3), name: 'Grilled Chicken Sandwich', description: 'Grilled chicken breast with cheese and veggies.', price: 450, image: sandwichImg3, category: 'sandwiches' },
  { id: id('sandwiches', 4), name: 'Crispy Chicken Sandwich', description: 'Crispy fried chicken fillet with fresh lettuce.', price: 460, image: sandwichImg4, category: 'sandwiches' },
  { id: id('sandwiches', 5), name: 'Chicken Cheese Sandwich', description: 'Melted cheese with chicken and herbs.', price: 420, image: sandwichImg5, category: 'sandwiches' },
  { id: id('sandwiches', 6), name: 'BBQ Chicken Sandwich', description: 'Smoky BBQ chicken with caramelized onions.', price: 470, image: sandwichImg, category: 'sandwiches' },
  { id: id('sandwiches', 7), name: 'Chicken Tikka Sandwich', description: 'Tandoori-spiced chicken tikka in a fresh sandwich.', price: 450, image: sandwichImg2, category: 'sandwiches', tags: ['spicy'] },
  { id: id('sandwiches', 8), name: 'Egg and Cheese Sandwich', description: 'Fluffy omelette with melted cheese.', price: 320, image: sandwichImg3, category: 'sandwiches' },
  { id: id('sandwiches', 9), name: 'Vegetable Sandwich', description: 'Fresh garden vegetables with cheese spread.', price: 300, image: sandwichImg4, category: 'sandwiches', tags: ['veg'] },
  { id: id('sandwiches', 10), name: 'Tuna Sandwich', description: 'Tuna salad with fresh vegetables and mayo.', price: 480, image: sandwichImg5, category: 'sandwiches' },
  { id: id('sandwiches', 11), name: 'Panini Chicken Sandwich', description: 'Grilled panini with chicken and melted cheese.', price: 500, image: sandwichImg, category: 'sandwiches', tags: ['popular'] },
  { id: id('sandwiches', 12), name: 'ZOBRO Special Sandwich', description: 'Our signature loaded sandwich with chicken, cheese, and sauces.', price: 580, image: sandwichImg2, category: 'sandwiches', tags: ['chef'] },

  // ROLLS — 14
  { id: id('rolls', 1), name: 'Chicken Mayo Roll', description: 'Creamy chicken mayo in a soft paratha wrap.', price: 320, image: wrapImg, category: 'rolls' },
  { id: id('rolls', 2), name: 'Chicken Garlic Roll', description: 'Garlic-infused chicken in a fresh roll.', price: 340, image: wrapImg2, category: 'rolls' },
  { id: id('rolls', 3), name: 'Chicken Tikka Roll', description: 'Spicy chicken tikka with onions and chutney.', price: 360, image: wrapImg3, category: 'rolls', tags: ['spicy', 'popular'] },
  { id: id('rolls', 4), name: 'Chicken Malai Boti Roll', description: 'Creamy malai boti in a soft paratha.', price: 380, image: wrapImg4, category: 'rolls' },
  { id: id('rolls', 5), name: 'BBQ Chicken Roll', description: 'Smoky BBQ chicken with fresh veggies.', price: 380, image: wrapImg5, category: 'rolls' },
  { id: id('rolls', 6), name: 'Zinger Roll', description: 'Crispy zinger chicken with spicy mayo.', price: 400, image: wrapImg, category: 'rolls', tags: ['spicy', 'popular'] },
  { id: id('rolls', 7), name: 'Crispy Chicken Wrap', description: 'Crispy chicken with fresh vegetables in a tortilla wrap.', price: 420, image: wrapImg2, category: 'rolls' },
  { id: id('rolls', 8), name: 'Grilled Chicken Wrap', description: 'Grilled chicken with healthy veggies in a wrap.', price: 440, image: wrapImg3, category: 'rolls' },
  { id: id('rolls', 9), name: 'Peri Peri Wrap', description: 'Peri peri chicken with crisp lettuce.', price: 440, image: wrapImg4, category: 'rolls', tags: ['spicy'] },
  { id: id('rolls', 10), name: 'Mexican Chicken Wrap', description: 'Mexican-spiced chicken with salsa.', price: 460, image: wrapImg5, category: 'rolls', tags: ['spicy'] },
  { id: id('rolls', 11), name: 'Beef Seekh Kebab Roll', description: 'Juicy beef seekh kebab in a paratha roll.', price: 420, image: wrapImg, category: 'rolls' },
  { id: id('rolls', 12), name: 'Chicken Cheese Roll', description: 'Chicken with molten cheese in a paratha.', price: 400, image: wrapImg2, category: 'rolls' },
  { id: id('rolls', 13), name: 'Chicken Paratha Roll', description: 'Classic chicken filling in a crispy paratha.', price: 360, image: wrapImg3, category: 'rolls', tags: ['popular'] },
  { id: id('rolls', 14), name: 'ZOBRO Special Roll', description: 'Our signature roll with double chicken and special sauce.', price: 520, image: wrapImg4, category: 'rolls', tags: ['chef'] },

  // BROAST — 12
  { id: id('broast', 1), name: 'Crispy Chicken Broast', description: 'Golden crispy broasted chicken with special seasoning.', price: 450, image: friedImg, category: 'broast', tags: ['popular'], serves: '2 pcs', extras: ['Add 2 pcs +400', 'Family Bucket (8 pcs) +1600'] },
  { id: id('broast', 2), name: 'Spicy Chicken Broast', description: 'Hot and spicy broasted chicken with chili seasoning.', price: 470, image: friedImg2, category: 'broast', tags: ['spicy'], serves: '2 pcs', extras: ['Add 2 pcs +420'] },
  { id: id('broast', 3), name: 'Original Fried Chicken', description: 'Classic Southern-style fried chicken.', price: 430, image: friedImg3, category: 'broast', serves: '2 pcs', extras: ['Add 2 pcs +380'] },
  { id: id('broast', 4), name: 'Hot and Spicy Fried Chicken', description: 'Extra spicy fried chicken with a fiery kick.', price: 450, image: friedImg4, category: 'broast', tags: ['spicy'], serves: '2 pcs' },
  { id: id('broast', 5), name: 'Crispy Chicken Strips', description: 'Tender chicken strips with crispy coating.', price: 380, image: friedImg5, category: 'broast', serves: '4 pcs' },
  { id: id('broast', 6), name: 'Chicken Tenders', description: 'Mild and juicy chicken tenders with dip.', price: 400, image: friedImg, category: 'broast', serves: '5 pcs' },
  { id: id('broast', 7), name: 'Chicken Nuggets', description: 'Bite-sized crispy chicken nuggets.', price: 320, image: friedImg2, category: 'broast', serves: '8 pcs' },
  { id: id('broast', 8), name: 'Chicken Wings', description: 'Classic fried chicken wings with sauce.', price: 420, image: friedImg3, category: 'broast', serves: '6 pcs' },
  { id: id('broast', 9), name: 'Hot Wings', description: 'Spicy buffalo-style hot wings.', price: 450, image: friedImg4, category: 'broast', tags: ['spicy'], serves: '6 pcs' },
  { id: id('broast', 10), name: 'BBQ Wings', description: 'Smoky BBQ glazed chicken wings.', price: 450, image: friedImg5, category: 'broast', serves: '6 pcs' },
  { id: id('broast', 11), name: 'Peri Peri Wings', description: 'Peri peri glazed wings with a spicy kick.', price: 470, image: friedImg, category: 'broast', tags: ['spicy'], serves: '6 pcs' },
  { id: id('broast', 12), name: 'Boneless Chicken Bites', description: 'Juicy boneless chicken bites with your choice of sauce.', price: 420, image: friedImg2, category: 'broast', serves: '8 pcs' },

  // BBQ — 14
  { id: id('bbq', 1), name: 'Chicken Tikka', description: 'Classic charcoal-grilled chicken tikka with spices.', price: 420, image: bbqImg, category: 'bbq', tags: ['spicy', 'popular'], serves: '4 pcs' },
  { id: id('bbq', 2), name: 'Chicken Malai Tikka', description: 'Creamy and mild malai-marinated grilled chicken.', price: 450, image: bbqImg2, category: 'bbq', serves: '4 pcs' },
  { id: id('bbq', 3), name: 'Chicken Boti', description: 'Tender boneless chicken boti with BBQ spices.', price: 440, image: bbqImg3, category: 'bbq', serves: '6 pcs' },
  { id: id('bbq', 4), name: 'Chicken Malai Boti', description: 'Creamy malai-marinated boneless chicken boti.', price: 460, image: bbqImg4, category: 'bbq', serves: '6 pcs' },
  { id: id('bbq', 5), name: 'Chicken Seekh Kebab', description: 'Juicy grilled chicken seekh kebabs.', price: 400, image: bbqImg5, category: 'bbq', serves: '4 pcs' },
  { id: id('bbq', 6), name: 'Beef Seekh Kebab', description: 'Spiced beef seekh kebabs grilled to perfection.', price: 450, image: bbqImg, category: 'bbq', serves: '4 pcs' },
  { id: id('bbq', 7), name: 'Chapli Kebab', description: 'Traditional Peshawari-style chapli kebab.', price: 480, image: bbqImg2, category: 'bbq', serves: '2 pcs', tags: ['popular'] },
  { id: id('bbq', 8), name: 'Chicken Reshmi Kebab', description: 'Silky-textured reshmi kebab with mild spices.', price: 460, image: bbqImg3, category: 'bbq', serves: '4 pcs' },
  { id: id('bbq', 9), name: 'BBQ Chicken Leg', description: 'Whole marinated chicken leg grilled on charcoal.', price: 480, image: bbqImg4, category: 'bbq', serves: '1 pc' },
  { id: id('bbq', 10), name: 'Chicken Shashlik', description: 'Grilled chicken with bell peppers and onions on skewers.', price: 500, image: bbqImg5, category: 'bbq' },
  { id: id('bbq', 11), name: 'Grilled Chicken Breast', description: 'Perfectly grilled chicken breast with herbs.', price: 520, image: bbqImg, category: 'bbq' },
  { id: id('bbq', 12), name: 'Chicken Cheese Kebab', description: 'Kebab stuffed with molten cheese.', price: 520, image: bbqImg2, category: 'bbq', tags: ['chef'] },
  { id: id('bbq', 13), name: 'BBQ Platter', description: 'A generous mix of tikka, boti, kebab, and wings. Serves 2-3.', price: 1800, image: bbqImg3, category: 'bbq', tags: ['chef'], serves: '2-3' },
  { id: id('bbq', 14), name: 'ZOBRO Mixed Grill Platter', description: 'The ultimate grill feast — malai boti, seekh, tikka, and reshmi. Serves 3-4.', price: 2400, image: bbqImg4, category: 'bbq', tags: ['chef', 'popular'], serves: '3-4' },

  // PAKISTANI — 16
  { id: id('pakistani', 1), name: 'Chicken Biryani', description: 'Aromatic basmati rice with spiced chicken and herbs.', price: 380, image: biryaniImg, category: 'pakistani', tags: ['popular'] },
  { id: id('pakistani', 2), name: 'Beef Biryani', description: 'Tender beef biryani with rich spices.', price: 420, image: biryaniImg2, category: 'pakistani' },
  { id: id('pakistani', 3), name: 'Sindhi Biryani', description: 'Authentic Sindhi-style spicy biryani with aloo bukhara. A Sindhi specialty.', price: 420, image: biryaniImg3, category: 'pakistani', tags: ['spicy', 'popular'] },
  { id: id('pakistani', 4), name: 'Chicken Pulao', description: 'Fragrant yakhni pulao with tender chicken.', price: 380, image: biryaniImg4, category: 'pakistani' },
  { id: id('pakistani', 5), name: 'Chicken Karahi', description: 'Classic chicken karahi in a rich tomato-based gravy.', price: 750, image: karahiImg, category: 'pakistani', tags: ['popular'], serves: '2-3' },
  { id: id('pakistani', 6), name: 'White Chicken Karahi', description: 'Creamy white karahi with mild spices.', price: 820, image: karahiImg2, category: 'pakistani', serves: '2-3' },
  { id: id('pakistani', 7), name: 'Chicken Handi', description: 'Traditional chicken handi simmered in rich gravy.', price: 720, image: karahiImg3, category: 'pakistani', serves: '2-3' },
  { id: id('pakistani', 8), name: 'Chicken Achari Handi', description: 'Tangy achari-spiced chicken handi.', price: 750, image: karahiImg4, category: 'pakistani', tags: ['spicy'], serves: '2-3' },
  { id: id('pakistani', 9), name: 'Mutton Karahi', description: 'Tender mutton karahi with bold spices.', price: 1200, image: karahiImg5, category: 'pakistani', serves: '2-3' },
  { id: id('pakistani', 10), name: 'Beef Karahi', description: 'Slow-cooked beef karahi in rich masala.', price: 900, image: karahiImg, category: 'pakistani', serves: '2-3' },
  { id: id('pakistani', 11), name: 'Chicken Qorma', description: 'Rich and aromatic chicken qorma with nuts and spices.', price: 680, image: karahiImg2, category: 'pakistani' },
  { id: id('pakistani', 12), name: 'Daal Fry', description: 'Tadka-style fried daal with cumin and garlic.', price: 280, image: karahiImg3, category: 'pakistani', tags: ['veg'] },
  { id: id('pakistani', 13), name: 'Daal Chawal', description: 'Comforting daal served with steamed rice.', price: 320, image: karahiImg4, category: 'pakistani', tags: ['veg'] },
  { id: id('pakistani', 14), name: 'Sai Bhaji', description: 'Traditional Sindhi spinach curry with vegetables.', price: 300, image: karahiImg5, category: 'pakistani', tags: ['veg'] },
  { id: id('pakistani', 15), name: 'Sindhi Kadhi', description: 'Authentic Sindhi tangy gram flour curry with vegetables.', price: 320, image: karahiImg, category: 'pakistani', tags: ['veg'] },
  { id: id('pakistani', 16), name: 'Traditional Roti and Naan Selection', description: 'Freshly baked tandoori roti, naan, and garlic naan.', price: 40, image: biryaniImg2, category: 'pakistani', serves: 'per piece' },

  // FRIES — 12
  { id: id('fries', 1), name: 'Classic Salted Fries', description: 'Golden crispy fries sprinkled with salt.', price: 200, image: friesImg, category: 'fries' },
  { id: id('fries', 2), name: 'Masala Fries', description: 'Fries tossed in ZOBRO masala blend.', price: 240, image: friesImg2, category: 'fries', tags: ['spicy'] },
  { id: id('fries', 3), name: 'Crispy Curly Fries', description: 'Seasoned curly fries with a crispy crunch.', price: 260, image: friesImg3, category: 'fries' },
  { id: id('fries', 4), name: 'Potato Wedges', description: 'Thick-cut potato wedges with seasoning.', price: 240, image: friesImg4, category: 'fries' },
  { id: id('fries', 5), name: 'Cheese Fries', description: 'Fries smothered in melted cheese.', price: 320, image: friesImg5, category: 'fries', tags: ['popular'] },
  { id: id('fries', 6), name: 'Loaded Chicken Fries', description: 'Fries loaded with chicken, cheese, and sauces.', price: 420, image: friesImg, category: 'fries' },
  { id: id('fries', 7), name: 'Peri Peri Fries', description: 'Fries tossed in spicy peri peri seasoning.', price: 280, image: friesImg2, category: 'fries', tags: ['spicy'] },
  { id: id('fries', 8), name: 'Garlic Parmesan-Style Fries', description: 'Fries with garlic butter and parmesan.', price: 300, image: friesImg3, category: 'fries' },
  { id: id('fries', 9), name: 'Onion Rings', description: 'Crispy battered onion rings.', price: 280, image: friesImg4, category: 'fries' },
  { id: id('fries', 10), name: 'Mozzarella Sticks', description: 'Golden fried mozzarella sticks with marinara dip.', price: 350, image: friesImg5, category: 'fries' },
  { id: id('fries', 11), name: 'Garlic Bread', description: 'Toasted garlic bread with herbs and butter.', price: 250, image: friesImg, category: 'fries', tags: ['veg'] },
  { id: id('fries', 12), name: 'Cheesy Garlic Bread', description: 'Garlic bread loaded with melted cheese.', price: 320, image: friesImg2, category: 'fries', tags: ['veg', 'popular'] },

  // MOMOS — 10
  { id: id('momos', 1), name: 'Steamed Chicken Momos', description: 'Soft steamed dumplings filled with spiced chicken.', price: 320, image: momosImg, category: 'momos', tags: ['popular'], serves: '8 pcs' },
  { id: id('momos', 2), name: 'Fried Chicken Momos', description: 'Crispy fried momos with juicy chicken filling.', price: 350, image: momosImg2, category: 'momos', serves: '8 pcs' },
  { id: id('momos', 3), name: 'Spicy Chicken Momos', description: 'Hot and spicy chicken momos with chili sauce.', price: 360, image: momosImg3, category: 'momos', tags: ['spicy'], serves: '8 pcs' },
  { id: id('momos', 4), name: 'Chicken Cheese Momos', description: 'Momos stuffed with chicken and molten cheese.', price: 400, image: momosImg4, category: 'momos', serves: '8 pcs' },
  { id: id('momos', 5), name: 'Vegetable Momos', description: 'Steamed dumplings with fresh vegetable filling.', price: 280, image: momosImg5, category: 'momos', tags: ['veg'], serves: '8 pcs' },
  { id: id('momos', 6), name: 'Pan-Fried Momos', description: 'Momos pan-fried till crispy on the bottom.', price: 340, image: momosImg, category: 'momos', serves: '8 pcs' },
  { id: id('momos', 7), name: 'Crispy Momos', description: 'Deep-fried crunchy momos with dip.', price: 350, image: momosImg2, category: 'momos', serves: '8 pcs' },
  { id: id('momos', 8), name: 'Chicken Dumplings', description: 'Authentic steamed chicken dumplings with soy dip.', price: 360, image: momosImg3, category: 'momos', serves: '6 pcs' },
  { id: id('momos', 9), name: 'Vegetable Spring Rolls', description: 'Crispy spring rolls with vegetable filling.', price: 280, image: springRollImg, category: 'momos', tags: ['veg'], serves: '6 pcs' },
  { id: id('momos', 10), name: 'Chicken Spring Rolls', description: 'Golden crispy spring rolls with spiced chicken.', price: 320, image: springRollImg, category: 'momos', serves: '6 pcs' },

  // STREET FOOD — 12
  { id: id('streetfood', 1), name: 'Aloo Samosa', description: 'Crispy samosa with spiced potato filling.', price: 60, image: streetImg, category: 'streetfood', tags: ['veg'], serves: '2 pcs' },
  { id: id('streetfood', 2), name: 'Chicken Samosa', description: 'Crispy samosa stuffed with spiced chicken.', price: 80, image: streetImg2, category: 'streetfood', serves: '2 pcs' },
  { id: id('streetfood', 3), name: 'Beef Samosa', description: 'Savoury beef-filled crispy samosas.', price: 90, image: streetImg3, category: 'streetfood', serves: '2 pcs' },
  { id: id('streetfood', 4), name: 'Vegetable Samosa', description: 'Mixed vegetable samosa with herbs.', price: 60, image: streetImg, category: 'streetfood', tags: ['veg'], serves: '2 pcs' },
  { id: id('streetfood', 5), name: 'Crispy Pakora', description: 'Gram flour pakoras with onions and potatoes.', price: 150, image: streetImg2, category: 'streetfood', tags: ['veg'] },
  { id: id('streetfood', 6), name: 'Chicken Pakora', description: 'Spiced chicken pakoras, crispy and juicy.', price: 200, image: streetImg3, category: 'streetfood', tags: ['spicy'] },
  { id: id('streetfood', 7), name: 'Dahi Bhallay', description: 'Soft lentil dumplings in yogurt with chutneys.', price: 180, image: streetImg4, category: 'streetfood', tags: ['veg'] },
  { id: id('streetfood', 8), name: 'Gol Gappay', description: 'Crispy puris with tangy flavored water and fillings.', price: 200, image: streetImg, category: 'streetfood', tags: ['spicy', 'popular'] },
  { id: id('streetfood', 9), name: 'Chana Chaat', description: 'Spiced chickpea chaat with fresh vegetables.', price: 180, image: streetImg2, category: 'streetfood', tags: ['veg'] },
  { id: id('streetfood', 10), name: 'Fruit Chaat', description: 'Seasonal fruits with tangy masala and lemon.', price: 180, image: streetImg3, category: 'streetfood', tags: ['veg'] },
  { id: id('streetfood', 11), name: 'Bun Kebab', description: 'Classic street-style kebab in a bun with chutney.', price: 200, image: streetImg4, category: 'streetfood', tags: ['popular'] },
  { id: id('streetfood', 12), name: 'Shami Kebab', description: 'Crispy lentil and meat shami kebabs.', price: 220, image: streetImg, category: 'streetfood', serves: '3 pcs' },

  // PASTA — 10
  { id: id('pasta', 1), name: 'Creamy Alfredo Chicken Pasta', description: 'Rich and creamy alfredo sauce with grilled chicken.', price: 520, image: pastaImg, category: 'pasta', tags: ['popular'] },
  { id: id('pasta', 2), name: 'Spicy Arrabbiata Pasta', description: 'Spicy tomato and garlic arrabbiata sauce.', price: 480, image: pastaImg2, category: 'pasta', tags: ['spicy'] },
  { id: id('pasta', 3), name: 'Chicken Macaroni', description: 'Creamy macaroni with chicken and cheese.', price: 420, image: pastaImg3, category: 'pasta' },
  { id: id('pasta', 4), name: 'Chicken Lasagna', description: 'Layered lasagna with chicken and cheese.', price: 550, image: pastaImg4, category: 'pasta', tags: ['popular'] },
  { id: id('pasta', 5), name: 'Baked Pasta', description: 'Oven-baked pasta with cheese and herbs.', price: 500, image: pastaImg5, category: 'pasta' },
  { id: id('pasta', 6), name: 'Creamy Mushroom Pasta', description: 'Pasta in a creamy mushroom sauce.', price: 480, image: pastaImg, category: 'pasta' },
  { id: id('pasta', 7), name: 'Chicken Penne Pasta', description: 'Penne pasta with chicken in tomato sauce.', price: 460, image: pastaImg2, category: 'pasta' },
  { id: id('pasta', 8), name: 'Mac and Cheese', description: 'Classic macaroni with rich cheese sauce.', price: 400, image: pastaImg3, category: 'pasta', tags: ['veg'] },
  { id: id('pasta', 9), name: 'Chicken Parmesan-Style Pasta', description: 'Pasta with crispy chicken and parmesan.', price: 540, image: pastaImg4, category: 'pasta' },
  { id: id('pasta', 10), name: 'ZOBRO Special Pasta', description: 'Our signature pasta with mixed sauces and chicken.', price: 600, image: pastaImg5, category: 'pasta', tags: ['chef'] },

  // RICE — 10
  { id: id('rice', 1), name: 'Chicken Fried Rice', description: 'Wok-tossed fried rice with chicken and veggies.', price: 380, image: riceImg, category: 'rice', tags: ['popular'] },
  { id: id('rice', 2), name: 'Egg Fried Rice', description: 'Fried rice with scrambled egg and vegetables.', price: 340, image: riceImg2, category: 'rice' },
  { id: id('rice', 3), name: 'Vegetable Fried Rice', description: 'Healthy fried rice with mixed vegetables.', price: 320, image: riceImg3, category: 'rice', tags: ['veg'] },
  { id: id('rice', 4), name: 'Chicken Chow Mein', description: 'Stir-fried noodles with chicken and vegetables.', price: 400, image: riceImg4, category: 'rice' },
  { id: id('rice', 5), name: 'Chicken Manchurian with Rice', description: 'Spicy Manchurian chicken served with rice.', price: 440, image: riceImg5, category: 'rice', tags: ['spicy'] },
  { id: id('rice', 6), name: 'Chicken Shashlik with Rice', description: 'Grilled chicken skewers with spicy rice.', price: 460, image: riceImg, category: 'rice', tags: ['spicy'] },
  { id: id('rice', 7), name: 'Chicken Biryani Meal', description: 'Single-serve biryani with raita and salad.', price: 320, image: biryaniImg, category: 'rice' },
  { id: id('rice', 8), name: 'Burger and Fries Combo', description: 'A burger with crispy fries and a drink.', price: 750, image: burgerImg, category: 'rice', tags: ['popular'] },
  { id: id('rice', 9), name: 'Pizza and Wings Combo', description: 'Personal pizza with 6 chicken wings.', price: 1100, image: pizzaImg, category: 'rice' },
  { id: id('rice', 10), name: 'Family Feast Combo', description: 'Biryani, karahi, naan, and drinks for 4.', price: 2800, image: feastImg, category: 'rice', tags: ['chef'], serves: '4' },

  // CAKES — 12
  { id: id('cakes', 1), name: 'Chocolate Fudge Cake', description: 'Rich chocolate fudge cake with ganache.', price: 350, image: cakeImg, category: 'cakes', tags: ['popular'], serves: 'slice / whole' },
  { id: id('cakes', 2), name: 'Chocolate Truffle Cake', description: 'Decadent truffle layers with dark chocolate.', price: 380, image: cakeImg2, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 3), name: 'Red Velvet Cake', description: 'Moist red velvet with cream cheese frosting.', price: 380, image: cakeImg3, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 4), name: 'Black Forest Cake', description: 'Classic black forest with cherries and cream.', price: 360, image: cakeImg4, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 5), name: 'White Forest Cake', description: 'White chocolate and cherry forest cake.', price: 360, image: cakeImg5, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 6), name: 'Pineapple Cake', description: 'Light sponge with pineapple and cream.', price: 340, image: cakeImg, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 7), name: 'Coffee Cake', description: 'Rich coffee-flavored cake with cream.', price: 350, image: cakeImg2, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 8), name: 'Lotus Biscoff Cake', description: 'Biscoff spread cake with cookie crumble.', price: 420, image: cakeImg3, category: 'cakes', tags: ['popular'], serves: 'slice / whole' },
  { id: id('cakes', 9), name: 'Cheesecake', description: 'Creamy baked cheesecake with biscuit base.', price: 400, image: cheesecakeImg, category: 'cakes', serves: 'slice / whole' },
  { id: id('cakes', 10), name: 'Chocolate Brownies', description: 'Fudgy chocolate brownies with nuts.', price: 250, image: dessertImg3, category: 'cakes' },
  { id: id('cakes', 11), name: 'Chocolate Cupcakes', description: 'Moist cupcakes with chocolate frosting.', price: 180, image: cakeImg4, category: 'cakes', serves: '2 pcs' },
  { id: id('cakes', 12), name: 'Fresh Cream Cake', description: 'Light sponge with fresh cream and fruits.', price: 340, image: cakeImg5, category: 'cakes', serves: 'slice / whole' },

  // DESSERTS — 12
  { id: id('desserts', 1), name: 'Chocolate Lava Cake', description: 'Warm chocolate cake with molten center.', price: 320, image: dessertImg, category: 'desserts', tags: ['popular'] },
  { id: id('desserts', 2), name: 'Chocolate Brownie with Ice Cream', description: 'Warm brownie served with vanilla ice cream.', price: 350, image: dessertImg2, category: 'desserts' },
  { id: id('desserts', 3), name: 'Chocolate Sundae', description: 'Rich chocolate sundae with whipped cream.', price: 300, image: dessertImg4, category: 'desserts' },
  { id: id('desserts', 4), name: 'Vanilla Sundae', description: 'Classic vanilla sundae with toppings.', price: 280, image: dessertImg5, category: 'desserts' },
  { id: id('desserts', 5), name: 'Chocolate Mousse', description: 'Light and airy chocolate mousse.', price: 280, image: tiramisuImg3, category: 'desserts' },
  { id: id('desserts', 6), name: 'Tiramisu', description: 'Classic Italian tiramisu with coffee and mascarpone.', price: 350, image: tiramisuImg, category: 'desserts', tags: ['popular'] },
  { id: id('desserts', 7), name: 'Lotus Biscoff Dessert', description: 'Layered Biscoff dessert with cream.', price: 380, image: tiramisuImg2, category: 'desserts' },
  { id: id('desserts', 8), name: 'Oreo Dessert Cup', description: 'Crushed Oreos with cream layers.', price: 320, image: tiramisuImg3, category: 'desserts' },
  { id: id('desserts', 9), name: 'Chocolate Pudding', description: 'Rich and creamy chocolate pudding.', price: 280, image: tiramisuImg4, category: 'desserts' },
  { id: id('desserts', 10), name: 'Caramel Pudding', description: 'Silky caramel pudding with caramel sauce.', price: 280, image: tiramisuImg3, category: 'desserts' },
  { id: id('desserts', 11), name: 'Gulab Jamun', description: 'Traditional sweet dumplings in sugar syrup.', price: 220, image: gulabImg, category: 'desserts', serves: '4 pcs' },
  { id: id('desserts', 12), name: 'Kheer', description: 'Creamy rice pudding with cardamom and nuts.', price: 220, image: tiramisuImg4, category: 'desserts' },

  // SHAKES — 12
  { id: id('shakes', 1), name: 'Chocolate Milkshake', description: 'Thick chocolate milkshake with whipped cream.', price: 350, image: shakeImg, category: 'shakes', tags: ['popular'] },
  { id: id('shakes', 2), name: 'Vanilla Milkshake', description: 'Classic creamy vanilla milkshake.', price: 320, image: shakeImg2, category: 'shakes' },
  { id: id('shakes', 3), name: 'Strawberry Milkshake', description: 'Fresh strawberry milkshake with cream.', price: 340, image: shakeImg3, category: 'shakes' },
  { id: id('shakes', 4), name: 'Oreo Shake', description: 'Crushed Oreo cookies blended with milkshake.', price: 380, image: shakeImg2, category: 'shakes', tags: ['popular'] },
  { id: id('shakes', 5), name: 'KitKat Shake', description: 'KitKat pieces blended into a thick shake.', price: 400, image: shakeImg3, category: 'shakes' },
  { id: id('shakes', 6), name: 'Snickers Shake', description: 'Snickers bar milkshake with caramel and nuts.', price: 420, image: shakeImg4, category: 'shakes' },
  { id: id('shakes', 7), name: 'Lotus Biscoff Shake', description: 'Biscoff spread milkshake with cookie garnish.', price: 420, image: shakeImg2, category: 'shakes' },
  { id: id('shakes', 8), name: 'Mango Shake', description: 'Fresh mango milkshake, seasonal.', price: 340, image: shakeImg5, category: 'shakes' },
  { id: id('shakes', 9), name: 'Banana Shake', description: 'Creamy banana milkshake with honey.', price: 320, image: shakeImg3, category: 'shakes' },
  { id: id('shakes', 10), name: 'Peanut Butter Shake', description: 'Rich peanut butter milkshake.', price: 380, image: shakeImg4, category: 'shakes' },
  { id: id('shakes', 11), name: 'Coffee Milkshake', description: 'Blended coffee milkshake with ice cream.', price: 360, image: shakeImg, category: 'shakes' },
  { id: id('shakes', 12), name: 'ZOBRO Special Thick Shake', description: 'Our signature triple-thick shake with mixed toppings.', price: 450, image: shakeImg2, category: 'shakes', tags: ['chef'] },

  // BEVERAGES — 12
  { id: id('beverages', 1), name: 'Fresh Lemonade', description: 'Refreshing freshly squeezed lemonade.', price: 180, image: drinkImg, category: 'beverages' },
  { id: id('beverages', 2), name: 'Mint Lemonade', description: 'Lemonade with fresh mint and ice.', price: 200, image: drinkImg2, category: 'beverages' },
  { id: id('beverages', 3), name: 'Fresh Lime Soda', description: 'Sparkling lime soda, sweet or salty.', price: 160, image: drinkImg3, category: 'beverages' },
  { id: id('beverages', 4), name: 'Iced Coffee', description: 'Chilled iced coffee with milk.', price: 250, image: drinkImg4, category: 'beverages' },
  { id: id('beverages', 5), name: 'Cold Coffee', description: 'Thick blended cold coffee with ice cream.', price: 300, image: drinkImg5, category: 'beverages' },
  { id: id('beverages', 6), name: 'Iced Chocolate', description: 'Chilled chocolate drink with whipped cream.', price: 280, image: drinkImg, category: 'beverages' },
  { id: id('beverages', 7), name: 'Mango Smoothie', description: 'Fresh mango blended smoothie.', price: 280, image: drinkImg2, category: 'beverages' },
  { id: id('beverages', 8), name: 'Strawberry Smoothie', description: 'Fresh strawberry smoothie with yogurt.', price: 280, image: drinkImg3, category: 'beverages' },
  { id: id('beverages', 9), name: 'Mineral Water', description: 'Chilled bottled mineral water.', price: 80, image: drinkImg4, category: 'beverages' },
  { id: id('beverages', 10), name: 'Soft Drinks', description: 'Choice of popular soft drinks.', price: 100, image: drinkImg5, category: 'beverages' },
  { id: id('beverages', 11), name: 'Green Tea', description: 'Refreshing hot green tea.', price: 120, image: drinkImg, category: 'beverages' },
  { id: id('beverages', 12), name: 'Hot Coffee', description: 'Freshly brewed hot coffee.', price: 180, image: drinkImg2, category: 'beverages' },

  // ICE CREAM — 8
  { id: id('icecream', 1), name: 'Vanilla Ice Cream', description: 'Classic creamy vanilla ice cream.', price: 200, image: icecreamImg, category: 'icecream' },
  { id: id('icecream', 2), name: 'Chocolate Ice Cream', description: 'Rich chocolate ice cream.', price: 220, image: icecreamImg2, category: 'icecream' },
  { id: id('icecream', 3), name: 'Strawberry Ice Cream', description: 'Fresh strawberry ice cream.', price: 220, image: icecreamImg3, category: 'icecream' },
  { id: id('icecream', 4), name: 'Mango Ice Cream', description: 'Seasonal fresh mango ice cream.', price: 240, image: icecreamImg4, category: 'icecream' },
  { id: id('icecream', 5), name: 'Chocolate Chip Ice Cream', description: 'Vanilla ice cream with chocolate chips.', price: 240, image: icecreamImg5, category: 'icecream' },
  { id: id('icecream', 6), name: 'Brownie Sundae', description: 'Warm brownie with ice cream and chocolate sauce.', price: 350, image: icecreamImg, category: 'icecream', tags: ['popular'] },
  { id: id('icecream', 7), name: 'Cookie and Cream Sundae', description: 'Cookies and cream ice cream sundae.', price: 320, image: icecreamImg2, category: 'icecream' },
  { id: id('icecream', 8), name: 'ZOBRO Special Ice Cream', description: 'Our signature sundae with mixed toppings and sauces.', price: 380, image: icecreamImg3, category: 'icecream', tags: ['chef'] },

  // BREAKFAST — 8
  { id: id('breakfast', 1), name: 'Halwa Puri', description: 'Traditional halwa with crispy puris and chana.', price: 280, image: breakfastImg, category: 'breakfast', tags: ['popular'] },
  { id: id('breakfast', 2), name: 'Chana Puri', description: 'Spiced chana curry with fresh puris.', price: 280, image: breakfastImg2, category: 'breakfast' },
  { id: id('breakfast', 3), name: 'Aloo Paratha', description: 'Stuffed potato paratha with butter.', price: 180, image: breakfastImg3, category: 'breakfast', tags: ['veg'] },
  { id: id('breakfast', 4), name: 'Chicken Cheese Paratha', description: 'Paratha stuffed with chicken and cheese.', price: 280, image: breakfastImg4, category: 'breakfast' },
  { id: id('breakfast', 5), name: 'Plain Paratha', description: 'Crispy plain paratha with butter.', price: 100, image: breakfastImg5, category: 'breakfast', tags: ['veg'] },
  { id: id('breakfast', 6), name: 'Anda Paratha', description: 'Egg-filled paratha cooked on a tawa.', price: 200, image: breakfastImg, category: 'breakfast' },
  { id: id('breakfast', 7), name: 'Omelette with Toast', description: 'Fluffy omelette with toasted bread.', price: 220, image: breakfastImg2, category: 'breakfast' },
  { id: id('breakfast', 8), name: 'Desi Breakfast Platter', description: 'Halwa puri, omelette, paratha, and chai. Serves 2.', price: 480, image: breakfastImg3, category: 'breakfast', tags: ['chef'], serves: '2' },

  // KIDS — 6
  { id: id('kids', 1), name: 'Mini Chicken Burger', description: 'Kid-sized chicken burger with fries.', price: 300, image: kidsImg, category: 'kids' },
  { id: id('kids', 2), name: "Kids' Chicken Nuggets", description: '6 chicken nuggets with ketchup and fries.', price: 280, image: kidsImg2, category: 'kids' },
  { id: id('kids', 3), name: 'Mini Cheese Pizza', description: 'Personal 6-inch cheese pizza.', price: 350, image: kidsImg3, category: 'kids' },
  { id: id('kids', 4), name: 'Chicken Strips and Fries', description: 'Crispy chicken strips with a side of fries.', price: 320, image: kidsImg4, category: 'kids' },
  { id: id('kids', 5), name: 'Mini Chicken Sandwich', description: 'Small chicken sandwich with cheese.', price: 280, image: kidsImg5, category: 'kids' },
  { id: id('kids', 6), name: "Kids' Combo Meal", description: 'Mini burger, nuggets, fries, and a drink.', price: 450, image: kidsImg, category: 'kids', tags: ['popular'] },
];

export const deals: DealItem[] = [
  { id: 'deal-1', name: 'Single Person Meal', description: 'Perfect for one — burger, fries, and a drink.', price: 590, items: ['1 Burger', 'Regular Fries', 'Soft Drink'], image: feastImg3, badge: 'For One' },
  { id: 'deal-2', name: 'Student Deal', description: 'Budget-friendly meal for students.', price: 450, items: ['Zinger Roll', 'Fries', 'Soft Drink'], image: wrapImg, badge: 'Student' },
  { id: 'deal-3', name: 'Burger Combo', description: 'Two signature burgers with fries and drinks.', price: 1200, items: ['2 Burgers', 'Large Fries', '2 Soft Drinks'], image: burgerImg, badge: 'Popular' },
  { id: 'deal-4', name: 'Pizza Party Deal', description: 'Two large pizzas with wings and drinks.', price: 3500, items: ['2 Large Pizzas', '12 Wings', '2L Drink'], image: pizzaImg, badge: 'Party' },
  { id: 'deal-5', name: "Friends' Feast", description: 'A spread for 3-4 friends.', price: 2800, items: ['1 Large Pizza', '6 Wings', '2 Burgers', 'Fries', '2L Drink'], image: feastImg2, badge: 'Friends' },
  { id: 'deal-6', name: 'Couple Meal', description: 'A romantic meal for two.', price: 1500, items: ['2 Burgers', 'Loaded Fries', '2 Shakes'], image: feastImg, badge: 'For Two' },
  { id: 'deal-7', name: 'Family Deal', description: 'Complete family meal for 4-5.', price: 4200, items: ['2 Large Pizzas', '8 pcs Broast', 'Garlic Bread', '2L Drink'], image: feastImg2, badge: 'Family' },
  { id: 'deal-8', name: 'Family BBQ Platter', description: 'A generous BBQ platter for the whole family.', price: 3800, items: ['Mixed Grill Platter', 'Biryani', 'Naan', 'Drinks'], image: bbqImg3, badge: 'BBQ' },
  { id: 'deal-9', name: "Kids' Meal", description: 'A fun meal for the little ones.', price: 450, items: ['Mini Burger', 'Nuggets', 'Fries', 'Juice'], image: kidsImg, badge: 'Kids' },
  { id: 'deal-10', name: 'Dessert and Shake Combo', description: 'Sweet ending for two.', price: 800, items: ['2 Desserts', '2 Shakes'], image: shakeImg, badge: 'Sweet' },
];
