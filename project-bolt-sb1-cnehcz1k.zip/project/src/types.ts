export type SizeKey = 'S' | 'M' | 'L';

export interface MenuItemSize {
  label: string;
  price: number;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  tags?: ('veg' | 'spicy' | 'new' | 'popular' | 'chef')[];
  sizes?: MenuItemSize[];
  serves?: string;
  extras?: string[];
}

export interface MenuCategory {
  id: string;
  name: string;
  short: string;
  image: string;
  icon: string;
}

export interface DealItem {
  id: string;
  name: string;
  description: string;
  price: number;
  items: string[];
  image: string;
  badge?: string;
}
