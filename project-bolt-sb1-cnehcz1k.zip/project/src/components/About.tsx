import SmartImage from './SmartImage';

const aboutImg = 'https://images.pexels.com/photos/4997854/pexels-photo-4997854.jpeg?auto=compress&cs=tinysrgb&h=800&w=600';

export default function About() {
  return (
    <section id="about" className="overflow-hidden bg-brand-black py-24">
      <div className="container-x">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div className="relative animate-fade-up">
            <div className="overflow-hidden rounded-3xl shadow-2xl">
              <SmartImage src={aboutImg} alt="ZOBRO restaurant ambiance" className="aspect-[4/5] w-full object-cover" loading="eager" />
            </div>
            <div className="absolute -bottom-6 -right-6 hidden rounded-2xl bg-flame-500 p-6 text-white shadow-xl sm:block">
              <div className="font-display text-4xl font-black">20+</div>
              <div className="text-sm">Food Categories</div>
            </div>
          </div>

          <div className="animate-fade-up">
            <p className="section-eyebrow text-flame-400">About ZOBRO</p>
            <h2 className="mt-2 font-display text-4xl font-bold leading-tight text-white sm:text-5xl">
              More Than Food.
              <br />
              It's a <span className="text-flame-500">ZOBRO Experience.</span>
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-cream-100/80">
              At ZOBRO, every craving deserves something special. From the comforting flavours of Pakistani cuisine to the excitement of international fast food and the sweetness of irresistible desserts, we bring variety, flavour, and memorable food experiences together in one place.
            </p>

            <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
              {[
                { title: 'Desi & Sindhi Favourites', desc: 'Authentic biryani, karahi, and traditional specialties.' },
                { title: 'Global Fast Food', desc: 'Pizza, burgers, pasta, and more from around the world.' },
                { title: 'Sweet Endings', desc: 'Cakes, desserts, shakes, and ice cream for every mood.' },
                { title: 'Easy WhatsApp Ordering', desc: 'Browse, add to cart, and order in just a few taps.' },
              ].map((feat) => (
                <div key={feat.title} className="rounded-xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm">
                  <h4 className="font-display text-base font-bold text-flame-400">{feat.title}</h4>
                  <p className="mt-1 text-sm text-cream-100/70">{feat.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
