import { UtensilsCrossed, Leaf, Flame, MessageCircle, LayoutGrid, Heart } from 'lucide-react';

const features = [
  { icon: UtensilsCrossed, title: 'Variety for Every Craving', desc: 'From desi classics to global fast food and sweet treats — 200+ dishes in one place.' },
  { icon: Leaf, title: 'Freshly Prepared Food', desc: 'Every dish is made to order with fresh ingredients and careful preparation.' },
  { icon: Flame, title: 'Delicious Flavour Combinations', desc: 'Bold, balanced flavours crafted to satisfy every craving and mood.' },
  { icon: MessageCircle, title: 'Easy WhatsApp Ordering', desc: 'Add items to your cart and send your order straight to our WhatsApp in seconds.' },
  { icon: LayoutGrid, title: 'Convenient Menu Browsing', desc: 'Search, filter by category, and find exactly what you are craving in moments.' },
  { icon: Heart, title: 'A Welcoming Food Experience', desc: 'Great food served with warmth — we want every visit to feel memorable.' },
];

export default function WhyChooseUs() {
  return (
    <section className="bg-cream-100/50 py-20">
      <div className="container-x">
        <div className="mb-12 text-center">
          <p className="section-eyebrow">Why ZOBRO</p>
          <h2 className="mt-2 font-display text-4xl font-bold text-brand-black sm:text-5xl">
            Why Choose ZOBRO?
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                className="card-hover group rounded-2xl bg-white p-6 shadow-md"
              >
                <div className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-flame-50 text-flame-600 transition-colors group-hover:bg-flame-500 group-hover:text-white">
                  <Icon className="h-7 w-7" />
                </div>
                <h3 className="font-display text-lg font-bold text-brand-black">{feat.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-brand-espresso/70">{feat.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
