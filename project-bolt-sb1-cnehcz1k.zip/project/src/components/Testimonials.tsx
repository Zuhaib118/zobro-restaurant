import { Star, Quote } from 'lucide-react';

// NOTE: These are DEMONSTRATION testimonials — placeholder content.
// Replace with real customer reviews before launch.
const testimonials = [
  { name: 'Ayesha K.', text: 'The ZOBRO Special Pizza is absolutely incredible — the perfect blend of flavours. Ordering on WhatsApp was so easy!', rating: 5 },
  { name: 'Bilal R.', text: 'Their biryani and karahi taste just like home. The portions are generous and the food arrives fresh and hot.', rating: 5 },
  { name: 'Sana M.', text: 'Love the variety! From momos to milkshakes, there is something for everyone. The chocolate lava cake is a must-try.', rating: 5 },
  { name: 'Hamza A.', text: 'Best broast in the city. Crispy, juicy, and perfectly spiced. The family deal is great value too.', rating: 5 },
];

export default function Testimonials() {
  return (
    <section className="bg-brand-black py-20">
      <div className="container-x">
        <div className="mb-12 text-center">
          <p className="section-eyebrow text-flame-400">Testimonials</p>
          <h2 className="mt-2 font-display text-4xl font-bold text-white sm:text-5xl">
            What Our Guests Say
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-sm text-cream-100/60">
            The reviews below are demonstration content. Replace them with real customer feedback before launch.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="card-hover relative rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm"
            >
              <Quote className="mb-3 h-8 w-8 text-flame-500/60" />
              <blockquote className="text-sm leading-relaxed text-cream-100/85">
                "{t.text}"
              </blockquote>
              <div className="mt-4 flex gap-0.5">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-gold-400 text-gold-400" />
                ))}
              </div>
              <figcaption className="mt-3 font-display text-sm font-bold text-flame-400">— {t.name}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
