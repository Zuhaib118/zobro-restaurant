import { useState } from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark';
  showWordmark?: boolean;
}

export default function Logo({ className = '', variant = 'dark', showWordmark = true }: LogoProps) {
  const [imgError, setImgError] = useState(false);
  const text = variant === 'light' ? '#fbf6ef' : '#171310';

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-flame-500 to-flame-700 shadow-lg shadow-flame-500/30">
        {imgError ? (
          <span className="font-display text-2xl font-black text-white">Z</span>
        ) : (
          <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden="true">
            <path
              d="M34 10 L14 10 L14 16 L26 22 L14 28 L14 38 L34 38"
              fill="none"
              stroke="white"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="36" cy="14" r="2.5" fill="#ffd9b3" />
            <circle cx="12" cy="34" r="2.5" fill="#ffd9b3" />
          </svg>
        )}
      </div>
      {showWordmark && (
        <div className="leading-none">
          <div className="font-display text-2xl font-black tracking-tight" style={{ color: text }}>
            ZOBRO
          </div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.3em]" style={{ color: variant === 'light' ? '#e0c39b' : '#d94a12' }}>
            Every Craving
          </div>
        </div>
      )}
    </div>
  );
}
