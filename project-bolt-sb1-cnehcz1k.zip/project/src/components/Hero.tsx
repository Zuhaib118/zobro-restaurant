import { ArrowRight, MessageCircle, UtensilsCrossed } from 'lucide-react';
import SmartImage from './SmartImage';

const heroImg = 'https://images.pexels.com/photos/4628465/pexels-photo-4628465.jpeg?auto=compress&cs=tinysrgb&h=900&w=1600';

export default function Hero() {
  const scrollTo = (id: string) => document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section id="home" className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0">
        <SmartImage src={heroImg} alt="Gourmet burger, pizza, and sides spread" className="h-full w-full object-cover" loading="eager" />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-black/90 via-brand-black/70 to-brand-black/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-black via-transparent to-transparent" />
      </div>

      <div className="container-x relative flex min-h-screen flex-col justify-center pt-28 pb-16">
        <div className="max-w-2xl animate-fade-up">
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-flame-500/40 bg-flame-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-flame-300 backdrop-blur-sm">
            <UtensilsCrossed className="h-3.5 w-3.5" />
            Made for Every Craving
          </div>

          <h1 className="font-display text-5xl font-black leading-[1.05] text-white sm:text-6xl lg:text-7xl">
            Big Flavours.
            <br />
            <span className="text-flame-500">Unforgettable Moments.</span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-cream-100/90">
            From sizzling desi favourites to cheesy pizzas, juicy burgers, refreshing shakes, and irresistible desserts — discover something delicious for every craving.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <button onClick={() => scrollTo('#menu')} className="btn-primary group">
              Explore Our Menu
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
            <a href="https://wa.me/923332768127" target="_blank" rel="noopener noreferrer" className="btn-outline">
              <MessageCircle className="h-4 w-4" />
              Order on WhatsApp
            </a>
          </div>

          <div className="mt-12 flex flex-wrap gap-x-10 gap-y-4">
            {[
              { value: '20+', label: 'Food Categories' },
              { value: '200+', label: 'Menu Items' },
              { value: '1', label: 'Brand, Every Craving' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="font-display text-3xl font-bold text-flame-500">{stat.value}</div>
                <div className="text-sm text-cream-100/70">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-cream-50 to-transparent" />
    </section>
  );
}
