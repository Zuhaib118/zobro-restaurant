import { CheckCircle2, Tag } from 'lucide-react';
import { deals } from '@/data/menu';
import SmartImage from './SmartImage';

export default function Offers() {
  return (
    <section id="offers" className="bg-cream-50 py-20">
      <div className="container-x">
        <div className="mb-12 text-center">
          <p className="section-eyebrow">Special Offers</p>
          <h2 className="mt-2 font-display text-4xl font-bold text-brand-black sm:text-5xl">
            Your Favourites, Together for Less.
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-brand-espresso/70">
            Sample promotional deals — the owner can edit names, items, and prices before launch. Prices shown are demonstration only.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {deals.map((deal) => (
            <article key={deal.id} className="card-hover group overflow-hidden rounded-2xl bg-white shadow-md">
              <div className="relative aspect-[16/10] overflow-hidden">
                <SmartImage src={deal.image} alt={deal.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-black/60 to-transparent" />
                {deal.badge && (
                  <span className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full bg-flame-500 px-3 py-1 text-xs font-bold text-white shadow-lg">
                    <Tag className="h-3 w-3" />
                    {deal.badge}
                  </span>
                )}
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl font-bold text-brand-black">{deal.name}</h3>
                <p className="mt-1.5 text-sm text-brand-espresso/70">{deal.description}</p>
                <ul className="mt-4 space-y-1.5">
                  {deal.items.map((it: string) => (
                    <li key={it} className="flex items-center gap-2 text-sm text-brand-espresso/80">
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-green-500" />
                      {it}
                    </li>
                  ))}
                </ul>
                <div className="mt-5 flex items-center justify-between border-t border-cream-200 pt-4">
                  <div>
                    <span className="font-display text-2xl font-bold text-flame-600">Rs. {deal.price.toLocaleString()}</span>
                    <p className="text-[10px] uppercase tracking-wider text-brand-espresso/40">Sample price</p>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
