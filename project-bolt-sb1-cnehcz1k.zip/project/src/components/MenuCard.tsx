import { useState } from 'react';
import { Plus, Flame, Leaf, Sparkles, Star, ChefHat } from 'lucide-react';
import type { MenuItem } from '@/types';
import { useCart } from '@/context/CartContext';
import SmartImage from './SmartImage';

const tagConfig: Record<string, { label: string; icon: typeof Flame; cls: string }> = {
  spicy: { label: 'Spicy', icon: Flame, cls: 'bg-red-100 text-red-700' },
  veg: { label: 'Veg', icon: Leaf, cls: 'bg-green-100 text-green-700' },
  new: { label: 'New', icon: Sparkles, cls: 'bg-blue-100 text-blue-700' },
  popular: { label: 'Popular', icon: Star, cls: 'bg-gold-400/20 text-gold-600' },
  chef: { label: "Chef's Pick", icon: ChefHat, cls: 'bg-flame-100 text-flame-700' },
};

export default function MenuCard({ item }: { item: MenuItem }) {
  const { add } = useCart();
  const [selectedSize, setSelectedSize] = useState(0);

  const currentSize = item.sizes?.[selectedSize];
  const unitPrice = currentSize?.price ?? item.price;

  const handleAdd = () => {
    add(item, {
      sizeLabel: currentSize?.label,
      unitPrice,
    });
  };

  return (
    <article className="card-hover group flex flex-col overflow-hidden rounded-2xl bg-white shadow-md">
      <div className="relative aspect-[4/3] overflow-hidden">
        <SmartImage src={item.image} alt={item.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
        {item.tags && item.tags.length > 0 && (
          <div className="absolute left-3 top-3 flex flex-wrap gap-1.5">
            {item.tags.slice(0, 2).map((tag) => {
              const cfg = tagConfig[tag];
              if (!cfg) return null;
              const Icon = cfg.icon;
              return (
                <span key={tag} className={`chip ${cfg.cls} backdrop-blur-sm`}>
                  <Icon className="h-3 w-3" />
                  {cfg.label}
                </span>
              );
            })}
          </div>
        )}
        {item.serves && (
          <span className="absolute bottom-3 right-3 rounded-full bg-brand-black/70 px-2.5 py-1 text-xs font-medium text-cream-100 backdrop-blur-sm">
            {item.serves}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="font-display text-lg font-bold leading-snug text-brand-black">{item.name}</h3>
        <p className="mt-1.5 flex-1 text-sm leading-relaxed text-brand-espresso/70">{item.description}</p>

        {item.sizes && (
          <div className="mt-3 flex gap-1.5">
            {item.sizes.map((s, i) => (
              <button
                key={s.label}
                onClick={() => setSelectedSize(i)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-colors ${
                  i === selectedSize ? 'bg-flame-500 text-white' : 'bg-cream-100 text-brand-espresso hover:bg-cream-200'
                }`}
              >
                {s.label[0]}
              </button>
            ))}
          </div>
        )}

        {item.extras && (
          <div className="mt-2 flex flex-wrap gap-1">
            {item.extras.map((ex) => (
              <span key={ex} className="rounded-md bg-cream-100 px-2 py-0.5 text-[11px] text-brand-espresso/70">
                {ex}
              </span>
            ))}
          </div>
        )}

        <div className="mt-4 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="font-display text-xl font-bold text-flame-600">
              Rs. {unitPrice.toLocaleString()}
            </span>
            <span className="text-[10px] uppercase tracking-wider text-brand-espresso/40">Sample price</span>
          </div>
          <button
            onClick={handleAdd}
            className="inline-flex items-center gap-1.5 rounded-full bg-brand-black px-4 py-2.5 text-sm font-semibold text-white transition-all hover:bg-flame-500 hover:shadow-lg hover:shadow-flame-500/30 active:scale-95"
          >
            <Plus className="h-4 w-4" />
            Add
          </button>
        </div>
      </div>
    </article>
  );
}
