import { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X, Leaf, Flame } from 'lucide-react';
import { menuItems, categories } from '@/data/menu';
import MenuCard from './MenuCard';

interface MenuSectionProps {
  activeCategory: string;
  onSelectCategory: (id: string) => void;
}

export default function MenuSection({ activeCategory, onSelectCategory }: MenuSectionProps) {
  const [search, setSearch] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [vegOnly, setVegOnly] = useState(false);
  const [spicyOnly, setSpicyOnly] = useState(false);
  const [maxPrice, setMaxPrice] = useState(5000);

  const filtered = useMemo(() => {
    return menuItems.filter((item) => {
      if (activeCategory !== 'all' && item.category !== activeCategory) return false;
      if (search) {
        const q = search.toLowerCase();
        if (!item.name.toLowerCase().includes(q) && !item.description.toLowerCase().includes(q)) return false;
      }
      if (vegOnly && !item.tags?.includes('veg')) return false;
      if (spicyOnly && !item.tags?.includes('spicy')) return false;
      if (item.price > maxPrice) return false;
      return true;
    });
  }, [activeCategory, search, vegOnly, spicyOnly, maxPrice]);

  const activeCatName = categories.find((c) => c.id === activeCategory)?.name ?? 'All Items';

  return (
    <section id="menu" className="bg-cream-100/50 py-20">
      <div className="container-x">
        <div className="mb-10 text-center">
          <p className="section-eyebrow">Our Signature Menu</p>
          <h2 className="mt-2 font-display text-4xl font-bold text-brand-black sm:text-5xl">
            From Desi Favourites to Global Flavours
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-brand-espresso/70">
            Explore over 200 dishes across 20 categories. Prices shown are sample PKR prices and can be edited by the owner.
          </p>
        </div>

        {/* Category nav */}
        <div className="mb-6 flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          <button
            onClick={() => onSelectCategory('all')}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
              activeCategory === 'all' ? 'bg-flame-500 text-white shadow-md' : 'bg-white text-brand-espresso hover:bg-cream-100'
            }`}
          >
            All Items
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
                activeCategory === cat.id ? 'bg-flame-500 text-white shadow-md' : 'bg-white text-brand-espresso hover:bg-cream-100'
              }`}
            >
              {cat.short}
            </button>
          ))}
        </div>

        {/* Search + filter toggle */}
        <div className="mb-6 flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-brand-espresso/40" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search dishes..."
              className="w-full rounded-full border border-cream-200 bg-white py-3 pl-12 pr-4 text-sm text-brand-black outline-none transition-all focus:border-flame-400 focus:ring-2 focus:ring-flame-400/20"
            />
          </div>
          <button
            onClick={() => setShowFilters((v) => !v)}
            className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-colors ${
              showFilters ? 'bg-brand-black text-white' : 'bg-white text-brand-espresso hover:bg-cream-100'
            }`}
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
          </button>
        </div>

        {/* Filter panel */}
        {showFilters && (
          <div className="mb-6 flex flex-wrap items-center gap-4 rounded-2xl bg-white p-5 shadow-md animate-fade-in">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-brand-espresso">Filters:</span>
            </div>
            <button
              onClick={() => setVegOnly((v) => !v)}
              className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                vegOnly ? 'bg-green-500 text-white' : 'bg-cream-100 text-brand-espresso'
              }`}
            >
              <Leaf className="h-3.5 w-3.5" />
              Vegetarian
            </button>
            <button
              onClick={() => setSpicyOnly((v) => !v)}
              className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                spicyOnly ? 'bg-red-500 text-white' : 'bg-cream-100 text-brand-espresso'
              }`}
            >
              <Flame className="h-3.5 w-3.5" />
              Spicy
            </button>
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-brand-espresso">Max Price:</span>
              <input
                type="range"
                min={100}
                max={5000}
                step={100}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="accent-flame-500"
              />
              <span className="text-xs font-bold text-flame-600">Rs. {maxPrice.toLocaleString()}</span>
            </div>
            {(vegOnly || spicyOnly || maxPrice < 5000 || search) && (
              <button
                onClick={() => {
                  setVegOnly(false);
                  setSpicyOnly(false);
                  setMaxPrice(5000);
                  setSearch('');
                }}
                className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-flame-600 hover:underline"
              >
                <X className="h-3 w-3" />
                Clear all
              </button>
            )}
          </div>
        )}

        {/* Results */}
        <div className="mb-5 flex items-center justify-between">
          <h3 className="font-display text-2xl font-bold text-brand-black">{activeCatName}</h3>
          <span className="text-sm text-brand-espresso/60">{filtered.length} items</span>
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-2xl bg-white py-20 text-center shadow-sm">
            <Search className="mb-3 h-12 w-12 text-cream-300" />
            <p className="font-display text-xl font-bold text-brand-black">No dishes found</p>
            <p className="mt-1 text-sm text-brand-espresso/60">Try adjusting your search or filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((item) => (
              <MenuCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
