import { useState } from 'react';

interface SmartImageProps {
  src: string;
  alt: string;
  className?: string;
  loading?: 'lazy' | 'eager';
}

export default function SmartImage({ src, alt, className = '', loading = 'lazy' }: SmartImageProps) {
  const [error, setError] = useState(false);
  const [loaded, setLoaded] = useState(false);

  return (
    <>
      {!loaded && !error && (
        <div className={`absolute inset-0 animate-pulse bg-gradient-to-r from-cream-100 via-cream-200 to-cream-100 ${className}`} />
      )}
      {error ? (
        <div className={`flex items-center justify-center bg-cream-100 ${className}`}>
          <span className="font-display text-xl font-bold text-flame-500">ZOBRO</span>
        </div>
      ) : (
        <img
          src={src}
          alt={alt}
          loading={loading}
          onError={() => setError(true)}
          onLoad={() => setLoaded(true)}
          className={`${className} ${loaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-500`}
        />
      )}
    </>
  );
}
