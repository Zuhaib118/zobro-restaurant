import { useEffect, useState } from 'react';
import { ArrowUp, Phone, Mail, MessageCircle } from 'lucide-react';
import Logo from './Logo';
import { categories } from '@/data/menu';
import { WHATSAPP_DISPLAY, CONTACT_EMAIL, WHATSAPP_NUMBER } from '@/data/menu';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Our Menu', href: '#menu' },
  { label: 'About Us', href: '#about' },
  { label: 'Special Offers', href: '#offers' },
  { label: 'Contact', href: '#contact' },
];

export default function Footer() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 400);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (href: string) => document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <footer className="bg-brand-black text-cream-100">
      <div className="container-x py-16">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div>
            <Logo variant="light" />
            <p className="mt-4 text-sm leading-relaxed text-cream-100/60">
              One Brand. Every Craving. From sizzling desi favourites to global flavours — ZOBRO brings variety and memorable food experiences together.
            </p>
            <div className="mt-5 flex gap-3">
              <a
                href={`https://wa.me/${WHATSAPP_NUMBER}`}
                target="_blank"
                rel="noopener noreferrer"
                className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-green-600"
                aria-label="WhatsApp"
              >
                <MessageCircle className="h-5 w-5" />
              </a>
              <a
                href={`tel:${WHATSAPP_DISPLAY}`}
                className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-flame-500"
                aria-label="Call"
              >
                <Phone className="h-5 w-5" />
              </a>
              <a
                href={`mailto:${CONTACT_EMAIL}`}
                className="grid h-10 w-10 place-items-center rounded-full bg-white/10 text-white transition-colors hover:bg-blue-600"
                aria-label="Email"
              >
                <Mail className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-flame-400">Quick Links</h4>
            <ul className="mt-4 space-y-2">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="text-sm text-cream-100/70 transition-colors hover:text-flame-400"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-flame-400">Categories</h4>
            <ul className="mt-4 grid grid-cols-1 gap-2">
              {categories.slice(0, 8).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => scrollTo('#menu')}
                    className="text-sm text-cream-100/70 transition-colors hover:text-flame-400"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-flame-400">Contact</h4>
            <ul className="mt-4 space-y-3">
              <li className="flex items-center gap-2 text-sm text-cream-100/70">
                <Phone className="h-4 w-4 text-flame-500" />
                <a href={`tel:${WHATSAPP_DISPLAY}`} className="hover:text-flame-400">{WHATSAPP_DISPLAY}</a>
              </li>
              <li className="flex items-center gap-2 text-sm text-cream-100/70">
                <Mail className="h-4 w-4 text-flame-500" />
                <a href={`mailto:${CONTACT_EMAIL}`} className="break-all hover:text-flame-400">{CONTACT_EMAIL}</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 sm:flex-row">
          <p className="text-xs text-cream-100/50">
            &copy; {new Date().getFullYear()} ZOBRO. All rights reserved.
          </p>
          <p className="text-xs text-cream-100/40">One Brand. Every Craving.</p>
        </div>
      </div>

      {/* Back to top */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-6 right-6 z-40 grid h-12 w-12 place-items-center rounded-full bg-flame-500 text-white shadow-xl shadow-flame-500/40 transition-all hover:bg-flame-600 ${
          showTop ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-16 opacity-0'
        }`}
        aria-label="Back to top"
      >
        <ArrowUp className="h-5 w-5" />
      </button>
    </footer>
  );
}
