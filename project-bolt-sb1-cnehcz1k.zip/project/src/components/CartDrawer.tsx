import { useState } from 'react';
import { X, Minus, Plus, Trash2, ShoppingBag, MessageCircle, CheckCircle2, AlertCircle } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { WHATSAPP_NUMBER } from '@/data/menu';

export default function CartDrawer() {
  const { lines, isOpen, close, increment, decrement, remove, subtotal, count, clear } = useCart();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sent, setSent] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = 'Please enter your name';
    if (!phone.trim() || phone.replace(/\D/g, '').length < 10) e.phone = 'Please enter a valid phone number';
    if (!address.trim()) e.address = 'Please enter your delivery address';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const buildMessage = () => {
    const linesText = lines
      .map((l) => {
        const sizeStr = l.sizeLabel ? ` (${l.sizeLabel})` : '';
        const extrasStr = l.extras?.length ? ` + ${l.extras.join(', ')}` : '';
        return `• ${l.quantity}x ${l.item.name}${sizeStr}${extrasStr} — Rs. ${(l.unitPrice * l.quantity).toLocaleString()}`;
      })
      .join('\n');

    return (
      `*ZOBRO Order Request*\n\n` +
      `*Items:*\n${linesText}\n\n` +
      `*Subtotal:* Rs. ${subtotal.toLocaleString()}\n\n` +
      `*Customer Details:*\n` +
      `Name: ${name}\n` +
      `Phone: ${phone}\n` +
      `Address: ${address}\n` +
      (notes ? `Notes: ${notes}\n` : '') +
      `\n_Please confirm my order. Thank you!_`
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    const msg = encodeURIComponent(buildMessage());
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, '_blank');
    setSent(true);
    setTimeout(() => {
      setSent(false);
      clear();
      setName('');
      setPhone('');
      setAddress('');
      setNotes('');
    }, 4000);
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 z-[60] bg-brand-black/60 backdrop-blur-sm transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        onClick={close}
      />

      {/* Drawer */}
      <aside
        className={`fixed right-0 top-0 z-[70] flex h-full w-full max-w-md flex-col bg-cream-50 shadow-2xl transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-cream-200 bg-brand-black px-5 py-4 text-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-flame-500" />
            <h2 className="font-display text-lg font-bold">Your Cart {count > 0 && `(${count})`}</h2>
          </div>
          <button onClick={close} className="grid h-9 w-9 place-items-center rounded-full bg-white/10 hover:bg-white/20">
            <X className="h-5 w-5" />
          </button>
        </div>

        {sent ? (
          <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
            <CheckCircle2 className="mb-4 h-16 w-16 text-green-500" />
            <h3 className="font-display text-xl font-bold text-brand-black">WhatsApp is opening!</h3>
            <p className="mt-2 text-sm text-brand-espresso/70">
              Your order has been prepared. Please press send in WhatsApp to complete your order. Our team will confirm it shortly.
            </p>
          </div>
        ) : lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
            <div className="mb-4 grid h-20 w-20 place-items-center rounded-full bg-cream-100">
              <ShoppingBag className="h-10 w-10 text-cream-300" />
            </div>
            <h3 className="font-display text-xl font-bold text-brand-black">Your cart is empty</h3>
            <p className="mt-2 text-sm text-brand-espresso/60">Add some delicious items from the menu to get started.</p>
            <button onClick={close} className="btn-primary mt-6">Browse Menu</button>
          </div>
        ) : (
          <>
            {/* Items */}
            <div className="flex-1 overflow-y-auto px-5 py-4">
              <div className="space-y-3">
                {lines.map((line) => (
                  <div key={line.key} className="flex gap-3 rounded-xl bg-white p-3 shadow-sm">
                    <img src={line.item.image} alt={line.item.name} className="h-16 w-16 shrink-0 rounded-lg object-cover" />
                    <div className="flex flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-sm font-bold leading-snug text-brand-black">{line.item.name}</h4>
                        <button onClick={() => remove(line.key)} className="shrink-0 text-brand-espresso/40 hover:text-red-500">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      {line.sizeLabel && <span className="text-xs text-brand-espresso/60">{line.sizeLabel}</span>}
                      {line.extras && line.extras.length > 0 && (
                        <span className="text-xs text-brand-espresso/50">+ {line.extras.join(', ')}</span>
                      )}
                      <div className="mt-auto flex items-center justify-between pt-2">
                        <div className="flex items-center gap-1">
                          <button onClick={() => decrement(line.key)} className="grid h-7 w-7 place-items-center rounded-full bg-cream-100 hover:bg-cream-200">
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-8 text-center text-sm font-bold">{line.quantity}</span>
                          <button onClick={() => increment(line.key)} className="grid h-7 w-7 place-items-center rounded-full bg-cream-100 hover:bg-cream-200">
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <span className="text-sm font-bold text-flame-600">Rs. {(line.unitPrice * line.quantity).toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button onClick={clear} className="mt-4 text-xs font-semibold text-brand-espresso/50 hover:text-red-500">
                Clear all items
              </button>
            </div>

            {/* Checkout form */}
            <div className="border-t border-cream-200 bg-white px-5 py-4">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm font-semibold text-brand-espresso">Subtotal</span>
                <span className="font-display text-xl font-bold text-flame-600">Rs. {subtotal.toLocaleString()}</span>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3">
                <div>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your name *"
                    className={`w-full rounded-lg border bg-cream-50 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-flame-400/20 ${
                      errors.name ? 'border-red-400' : 'border-cream-200'
                    }`}
                  />
                  {errors.name && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertCircle className="h-3 w-3" />{errors.name}</p>}
                </div>
                <div>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Phone number *"
                    className={`w-full rounded-lg border bg-cream-50 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-flame-400/20 ${
                      errors.phone ? 'border-red-400' : 'border-cream-200'
                    }`}
                  />
                  {errors.phone && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertCircle className="h-3 w-3" />{errors.phone}</p>}
                </div>
                <div>
                  <textarea
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Delivery address *"
                    rows={2}
                    className={`w-full rounded-lg border bg-cream-50 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-flame-400/20 ${
                      errors.address ? 'border-red-400' : 'border-cream-200'
                    }`}
                  />
                  {errors.address && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertCircle className="h-3 w-3" />{errors.address}</p>}
                </div>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Order notes (optional)"
                  className="w-full rounded-lg border border-cream-200 bg-cream-50 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-flame-400/20"
                />

                <button type="submit" className="btn-primary w-full bg-green-600 hover:bg-green-700 shadow-green-600/30">
                  <MessageCircle className="h-4 w-4" />
                  Place Order on WhatsApp
                </button>
                <p className="text-center text-[11px] text-brand-espresso/50">
                  Your order is not confirmed until you send the WhatsApp message and we confirm it.
                </p>
              </form>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
