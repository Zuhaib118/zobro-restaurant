import { useState } from 'react';
import { Phone, Mail, MessageCircle, MapPin, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { WHATSAPP_NUMBER, WHATSAPP_DISPLAY, CONTACT_EMAIL } from '@/data/menu';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Please enter your name';
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Please enter a valid email';
    if (!form.message.trim()) e.message = 'Please enter a message';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    // Front-end demonstration — no backend configured.
    // Opens a mailto link as a fallback so the message reaches the restaurant.
    const subject = encodeURIComponent(`ZOBRO Contact Form — ${form.name}`);
    const body = encodeURIComponent(`Name: ${form.name}\nEmail: ${form.email}\n\n${form.message}`);
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
    setStatus('success');
    setForm({ name: '', email: '', message: '' });
    setTimeout(() => setStatus('idle'), 5000);
  };

  return (
    <section id="contact" className="bg-cream-50 py-20">
      <div className="container-x">
        <div className="mb-12 text-center">
          <p className="section-eyebrow">Get in Touch</p>
          <h2 className="mt-2 font-display text-4xl font-bold text-brand-black sm:text-5xl">Contact ZOBRO</h2>
          <p className="mx-auto mt-3 max-w-xl text-brand-espresso/70">
            Have a question or want to place an order? Reach out — we would love to hear from you.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Contact info */}
          <div className="space-y-4">
            <a
              href={`tel:${WHATSAPP_DISPLAY}`}
              className="card-hover flex items-center gap-4 rounded-2xl bg-white p-5 shadow-md"
            >
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-flame-50 text-flame-600">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-espresso/50">Call Us</p>
                <p className="font-display text-lg font-bold text-brand-black">{WHATSAPP_DISPLAY}</p>
              </div>
            </a>

            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="card-hover flex items-center gap-4 rounded-2xl bg-white p-5 shadow-md"
            >
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-green-50 text-green-600">
                <MessageCircle className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-espresso/50">WhatsApp</p>
                <p className="font-display text-lg font-bold text-brand-black">{WHATSAPP_DISPLAY}</p>
              </div>
            </a>

            <a
              href={`mailto:${CONTACT_EMAIL}`}
              className="card-hover flex items-center gap-4 rounded-2xl bg-white p-5 shadow-md"
            >
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-blue-50 text-blue-600">
                <Mail className="h-6 w-6" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-espresso/50">Email</p>
                <p className="truncate font-display text-base font-bold text-brand-black">{CONTACT_EMAIL}</p>
              </div>
            </a>

            <div className="flex items-center gap-4 rounded-2xl bg-white p-5 shadow-md">
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-cream-100 text-brand-espresso">
                <MapPin className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-espresso/50">Location</p>
                <p className="text-sm text-brand-espresso/70">Contact us for delivery areas and details.</p>
              </div>
            </div>
          </div>

          {/* Contact form */}
          <div className="rounded-2xl bg-white p-6 shadow-md sm:p-8">
            <h3 className="font-display text-xl font-bold text-brand-black">Send us a message</h3>
            <p className="mt-1 text-xs text-brand-espresso/50">
              This form opens your email app as a front-end demonstration. Connect a backend to send messages automatically.
            </p>

            {status === 'success' && (
              <div className="mt-4 flex items-center gap-2 rounded-xl bg-green-50 p-3 text-sm text-green-700">
                <CheckCircle2 className="h-5 w-5 shrink-0" />
                Your email app should have opened. If not, email us directly at {CONTACT_EMAIL}.
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              <div>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your name *"
                  className={`w-full rounded-lg border bg-cream-50 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-flame-400/20 ${
                    errors.name ? 'border-red-400' : 'border-cream-200'
                  }`}
                />
                {errors.name && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertCircle className="h-3 w-3" />{errors.name}</p>}
              </div>
              <div>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="Your email *"
                  className={`w-full rounded-lg border bg-cream-50 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-flame-400/20 ${
                    errors.email ? 'border-red-400' : 'border-cream-200'
                  }`}
                />
                {errors.email && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertCircle className="h-3 w-3" />{errors.email}</p>}
              </div>
              <div>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Your message *"
                  rows={4}
                  className={`w-full rounded-lg border bg-cream-50 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-flame-400/20 ${
                    errors.message ? 'border-red-400' : 'border-cream-200'
                  }`}
                />
                {errors.message && <p className="mt-1 flex items-center gap-1 text-xs text-red-500"><AlertCircle className="h-3 w-3" />{errors.message}</p>}
              </div>
              <button type="submit" className="btn-primary w-full">
                <Send className="h-4 w-4" />
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
