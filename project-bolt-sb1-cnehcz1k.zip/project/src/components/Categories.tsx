import * as Icons from 'lucide-react';
import type { MenuCategory } from '@/types';
import { categories } from '@/data/menu';
import SmartImage from './SmartImage';

interface CategoriesProps {
  active: string;
  onSelect: (id: string) => void;
}

export default function Categories({ active, onSelect }: CategoriesProps) {
  return (
    <section id="categories" className="bg-cream-50 py-20">
      <div className="container-x">
        <div className="mb-12 text-center">
          <p className="section-eyebrow">Explore by craving</p>
          <h2 className="mt-2 font-display text-4xl font-bold text-brand-black sm:text-5xl">Food Categories</h2>
          <p className="mx-auto mt-3 max-w-xl text-brand-espresso/70">
            From desi classics to global favourites — pick a category and dive into the menu.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {categories.map((cat: MenuCategory) => {
            const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[cat.icon] ?? Icons.Utensils;
            const isActive = active === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelect(cat.id)}
                className={`group relative aspect-square overflow-hidden rounded-2xl shadow-md transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl ${
                  isActive ? 'ring-2 ring-flame-500 ring-offset-2 ring-offset-cream-50' : ''
                }`}
              >
                <SmartImage src={cat.image} alt={cat.name} className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-black/85 via-brand-black/30 to-transparent" />
                <div className="absolute inset-0 flex flex-col items-center justify-end p-4 text-center">
                  <div className="mb-2 grid h-10 w-10 place-items-center rounded-full bg-flame-500/90 text-white shadow-lg">
                    <Icon className="h-5 w-5" />
                  </div>
                  <span className="font-display text-sm font-bold text-white drop-shadow">{cat.short}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
