import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { MenuItem } from '@/types';

export interface CartLine {
  key: string;
  item: MenuItem;
  quantity: number;
  sizeLabel?: string;
  unitPrice: number;
  extras?: string[];
}

interface CartContextValue {
  lines: CartLine[];
  add: (item: MenuItem, opts?: { sizeLabel?: string; unitPrice?: number; extras?: string[] }) => void;
  increment: (key: string) => void;
  decrement: (key: string) => void;
  remove: (key: string) => void;
  clear: () => void;
  count: number;
  subtotal: number;
  isOpen: boolean;
  open: () => void;
  close: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  const add: CartContextValue['add'] = useCallback((item, opts = {}) => {
    const sizeLabel = opts.sizeLabel;
    const unitPrice = opts.unitPrice ?? item.price;
    const extras = opts.extras;
    const key = [item.id, sizeLabel, (extras || []).join(',')].join('|');
    setLines((prev) => {
      const existing = prev.find((l) => l.key === key);
      if (existing) {
        return prev.map((l) => (l.key === key ? { ...l, quantity: l.quantity + 1 } : l));
      }
      return [...prev, { key, item, quantity: 1, sizeLabel, unitPrice, extras }];
    });
    setIsOpen(true);
  }, []);

  const increment = useCallback((key: string) => {
    setLines((prev) => prev.map((l) => (l.key === key ? { ...l, quantity: l.quantity + 1 } : l)));
  }, []);

  const decrement = useCallback((key: string) => {
    setLines((prev) =>
      prev
        .map((l) => (l.key === key ? { ...l, quantity: l.quantity - 1 } : l))
        .filter((l) => l.quantity > 0)
    );
  }, []);

  const remove = useCallback((key: string) => {
    setLines((prev) => prev.filter((l) => l.key !== key));
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const count = lines.reduce((s, l) => s + l.quantity, 0);
  const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.quantity, 0);

  return (
    <CartContext.Provider
      value={{ lines, add, increment, decrement, remove, clear, count, subtotal, isOpen, open: () => setIsOpen(true), close: () => setIsOpen(false) }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
